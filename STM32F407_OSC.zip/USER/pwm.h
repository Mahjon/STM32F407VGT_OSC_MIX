#ifndef __PWM_H
#define __PWM_H
#include "sys.h"
void TIM2_PWM_Init(u32 arr,u32 psc);
void Set_adc_sample_freq(TIM_TypeDef* TIMx,uint32_t psc);
#endif
