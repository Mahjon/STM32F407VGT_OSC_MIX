#include "includes.h"

extern volatile u32 tickCnt;
char MENU_FUNCTION[][9]={"Idle","Zoom","Cursor","Accuracy","Wave","Positon","Halt","Flash","Clock","NRF24L01"};//�˵����б�
MENU_LINKED_LIST *menu = &menu_osc_idle;

MENU_PAR menu1 =
{
	0,									//�˵�״̬��
	0,									//�˵���
	MENU_FUNCTION[0]					//��ǰ�˵���
};

MENU_LINKED_LIST menu_NRF24L01 = {
	.menu_id					= 9,
	.menu_level 			= 1,
	.function_name		=	MENU_FUNCTION[9],
	.menu_next        =	&menu_osc_zoom,
	.menu_sub					=	&menu_NRF24L01_sub1,
	.func							= menu_NRF24L01_func
};

MENU_LINKED_LIST menu_NRF24L01_sub1 = {
	.menu_id					= 9,
	.menu_level 			= 2,
	.function_name		=	MENU_FUNCTION[9],
	.menu_next        =	&menu_NRF24L01,
	.menu_sub					=	NULL,
	.func							= menu_NRF24L01_func_sub1
};

MENU_LINKED_LIST menu_clock = {
	.menu_id					= 8,
	.menu_level 			= 1,
	.function_name		=	MENU_FUNCTION[8],
	.menu_next        =	&menu_NRF24L01,
	.menu_sub					=	&menu_clock_sub,
	.func							= menu_clock_func
};

MENU_LINKED_LIST menu_clock_sub = {
	.menu_id					= 8,
	.menu_level 			= 2,
	.function_name		=	MENU_FUNCTION[8],
	.menu_next        =	&menu_clock,
	.menu_sub					=	NULL,
	.func							= menu_clock_func_sub
};

MENU_LINKED_LIST menu_osc_flash = {
	.menu_id					= 7,
	.menu_level 			= 1,
	.function_name		=	MENU_FUNCTION[7],
	.menu_next        =	&menu_clock,
	.menu_sub					=	&menu_osc_flash_sub1,
	.func							= menu_osc_flash_func
};

MENU_LINKED_LIST menu_osc_flash_sub1 = {
	.menu_id					= 7,
	.menu_level 			= 2,
	.function_name		=	MENU_FUNCTION[7],
	.menu_next        =	&menu_osc_flash_sub2,
	.menu_sub					=	NULL,
	.func							= menu_osc_flash_func_sub1
};	

MENU_LINKED_LIST menu_osc_flash_sub2 = {
	.menu_id					= 7,
	.menu_level 			= 3,
	.function_name		=	MENU_FUNCTION[7],
	.menu_next        =	&menu_osc_flash_sub1,
	.menu_sub					=	NULL,
	.func							= menu_osc_flash_func_sub2
};	
	
MENU_LINKED_LIST menu_halt = {
	.menu_id					= 6,
	.menu_level 			= 1,
	.function_name		=	MENU_FUNCTION[6],
	.menu_next        =	&menu_osc_flash,
	.menu_sub					=	NULL,
	.func							= menu_halt_func
};

MENU_LINKED_LIST menu_osc_wave = {
	.menu_id					= 4,
	.menu_level 			= 1,
	.function_name		=	MENU_FUNCTION[4],
	.menu_next        =	&menu_halt,
	.menu_sub					=	&menu_osc_wave_sub,
	.func							= menu_osc_wave_func
};

MENU_LINKED_LIST menu_osc_wave_sub = {
	.menu_id					= 4,
	.menu_level 			= 2,
	.function_name		=	MENU_FUNCTION[4],
	.menu_next        =	&menu_osc_wave,
	.menu_sub					=	NULL,
	.func							= menu_osc_wave_func_sub
};


MENU_LINKED_LIST menu_osc_accuracy = {
	.menu_id					= 3,
	.menu_level 			= 1,
	.function_name		=	MENU_FUNCTION[3],
	.menu_next        =	&menu_osc_wave,
	.menu_sub					=	&menu_osc_accuracy_sub,
	.func							= menu_osc_accuray_func
};

MENU_LINKED_LIST menu_osc_accuracy_sub = {
	.menu_id					= 3,
	.menu_level 			= 2,
	.function_name		=	MENU_FUNCTION[3],
	.menu_next        =	&menu_osc_accuracy,
	.menu_sub					=	NULL,
	.func							= menu_osc_accuray_func_sub
};

MENU_LINKED_LIST menu_osc_cursor = {
	.menu_id					= 2,
	.menu_level 			= 1,
	.function_name		=	MENU_FUNCTION[2],
	.menu_next        =	&menu_osc_accuracy,
	.menu_sub					=	&menu_osc_cursor_sub,
	.func							= menu_osc_cursor_func
};

MENU_LINKED_LIST menu_osc_cursor_sub = {
	.menu_id					= 2,
	.menu_level 			= 2,
	.function_name		=	MENU_FUNCTION[2],
	.menu_next        =	&menu_osc_cursor,
	.menu_sub					=	NULL,
	.func							= menu_osc_cursor_func_sub
};

MENU_LINKED_LIST menu_osc_position = {
	.menu_id					= 5,
	.menu_level 			= 2,
	.function_name		=	MENU_FUNCTION[5],
	.menu_next        =	&menu_osc_zoom,
	.menu_sub					=	NULL,
	.func							= menu_osc_position_func
};

MENU_LINKED_LIST menu_osc_zoom = {
	.menu_id					= 1,
	.menu_level 			= 1,
	.function_name		=	MENU_FUNCTION[1],
	.menu_next        = &menu_osc_cursor,
	.menu_sub					=	NULL,
	.func							= menu_osc_zoom_func
};

MENU_LINKED_LIST menu_osc_idle = {
	.menu_id					= 0,
	.menu_level 			= 0,
	.function_name		=	MENU_FUNCTION[0],
	.menu_next        = NULL,
	.menu_sub					=	&menu_osc_zoom,
	.func							= menu_osc_idle_func
};

/*osc_idle����*/
void menu_osc_idle_func(void)
{
	if(key1.knob_state == KNOB_CW)																											//˳ʱ����ת
	{
		if(osc.trigger_voltage < oled_par.heigh-1) osc.trigger_voltage+=1;
		else 
		{
			osc.trigger_voltage = oled_par.heigh-1;
			osc.trigger_function = 1;																												//����osc��������
		}
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		if(osc.trigger_voltage > 0) osc.trigger_voltage-=1;
		else 
		{
			osc.trigger_voltage = 0;
			osc.trigger_function = 0;																												//�ر�osc��������
		}
		key1.knob_state = KNOB_IDLE;
	}						
	if(key1.key_state == KEY_SHORT)																											//���������¶̰�ֹͣad�ɼ�
	{
		if(osc.osc_status == 0)
		{
			TIM_Cmd(TIM2, ENABLE);	
			osc.osc_status = 1;
		}
		else
		{
			TIM_Cmd(TIM2, DISABLE);  																											
			osc.osc_status = 0;																															//�ٴζ̰�����ad�ɼ�
		}
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											
	{
		menu = &menu_osc_zoom;																														//�������泤������˵���1�� Ĭ��ѡ��Zoom�˵�
		//menu_osc_idle.func = menu_osc_zoom_func;																					
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_osc_idle.menu_level;																				//��ǰ�˵���
	menu1.string_function = menu_osc_idle.function_name;																//��ǰ�˵���
}

/*osc_zoom����*/
void menu_osc_zoom_func(void)
{
	if(key1.knob_state == KNOB_CW)
	{	
		menu = menu_osc_zoom.menu_next;
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		menu = &menu_NRF24L01;
		key1.knob_state = KNOB_IDLE;
	}
	if(key1.key_state == KEY_SHORT)
	{
		menu_osc_zoom.func = menu_osc_zoom_func_sub;
		key1.key_state = KEY_IDLE;
	}
	else if(key1.key_state == KEY_LONG)
	{
		menu = &menu_osc_idle;		
		key1.key_state = KEY_IDLE;				
	}	
	menu1.menu_level = menu_osc_zoom.menu_level;																				//��ǰ�˵���
	menu1.string_function = menu_osc_zoom.function_name;																//��ǰ�˵���
}	

/*osc_zoom�Ӻ���*/
void menu_osc_zoom_func_sub(void)
{
	if(key1.knob_state == KNOB_CW)
	{
		if(osc.horizontal_div < 10) osc.horizontal_div +=1;	
		else osc.horizontal_div=1;
		key1.knob_state = KNOB_IDLE;			
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		if(osc.horizontal_div > 1)	osc.horizontal_div-=1;
		else osc.horizontal_div =10;	
		key1.knob_state = KNOB_IDLE;
	}
	if(key1.key_state == KEY_SHORT)																											//�̰�������ʾ��ʼλ�ò˵�
	{
		menu = &menu_osc_position;	
		key1.key_state = KEY_IDLE;
	}			
	if(key1.key_state == KEY_LONG)																											//�������ص�1��zoom�˵�
	{
		menu = &menu_osc_zoom;	
		menu_osc_zoom.func = menu_osc_zoom_func;
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_osc_zoom.menu_level+1;																			//��ǰ�˵���
	menu1.string_function = menu_osc_zoom.function_name;																//��ǰ�˵���
}
/*osc_position����*/
void menu_osc_position_func(void)					
{
	static uint32_t position_offset_delay=0;																						//������¼ƫ�÷���ͣ��ʱ��
	if(key1.knob_state == KNOB_CW)																											//��ť�ı���ʾ�Ŀ�ʼλ��
	{
		if(osc.position+osc.oled->width*osc.horizontal_div< SAMPLE_DATA_SIZE)osc.position+=(1*osc.horizontal_div);
		else osc.position = SAMPLE_DATA_SIZE-osc.oled->width*osc.horizontal_div;
		position_offset_delay = tickCnt;
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		if(osc.position > osc.horizontal_div) osc.position-=(1*osc.horizontal_div);
		else osc.position = 0;
		position_offset_delay = tickCnt;
		key1.knob_state = KNOB_IDLE;
	}			
	if(key1.key_state == KEY_SHORT)																										
	{
		menu = &menu_osc_zoom;																														//�̰�����zoom�Ӳ˵�
		menu_osc_zoom.func = menu_osc_zoom_func_sub;
		osc.position_select_countdown_state =0;
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//�������ص�1��zoom�˵�
	{
		menu = &menu_osc_zoom;	
		menu_osc_zoom.func = menu_osc_zoom_func;
		osc.position_select_countdown_state =0;
		key1.key_state = KEY_IDLE;
	}
	if(position_offset_delay - tickCnt == 0)																						//λ�ý���������ʱ��ʾʹ��
	{
		osc.position_select_countdown_state = 1;
	}
	else if((position_offset_delay+1000-tickCnt)/10 <=20)																//λ�ý���������ʱ��ʾʧ��
	{
		osc.position_select_countdown_state =0;
	}
	menu1.menu_level = menu_osc_position.menu_level;																		//��ǰ�˵���
	menu1.string_function = menu_osc_position.function_name;														//��ǰ�˵���	
}

/*osc_cursor����*/
void menu_osc_cursor_func(void)
{
	if(key1.knob_state == KNOB_CW)
	{
		menu = menu_osc_cursor.menu_next;			
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		menu = &menu_osc_zoom;		
		key1.knob_state = KNOB_IDLE;
	}
	if(key1.key_state == KEY_SHORT)																											//�̰����������ò˵�
	{
		menu = menu_osc_cursor.menu_sub;				
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//�������ش�������
	{
		menu = &menu_osc_idle;																						     		
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_osc_cursor.menu_level;																			//��ǰ�˵���
	menu1.string_function = menu_osc_cursor.function_name;															//��ǰ�˵���	
}

/*osc_cursor�Ӻ���*/	
void menu_osc_cursor_func_sub(void)
{
	static uint8_t flag_cursor = 0;
	if(key1.key_state == KEY_SHORT)																											//�̰��л���һ�����
	{			
		flag_cursor = !flag_cursor;
		key1.key_state = KEY_IDLE;
	}
	if(flag_cursor == 0)																																//���aѡ��
	{
		osc.cursor_select = 0;																					
		if(key1.knob_state == KNOB_CW)
		{
			if(osc.cursor_a < 127) 	osc.cursor_a+=1;		
			else osc.cursor_a=0;
			key1.knob_state = KNOB_IDLE;
		}
		else if(key1.knob_state == KNOB_CCW)
		{
			if(osc.cursor_a > 0) 	osc.cursor_a-=1;		
			else osc.cursor_a=127;
			key1.knob_state = KNOB_IDLE;
		}
	}
	else if	(flag_cursor == 1)																													//���bѡ��
	{
		osc.cursor_select = 1;																					
		if(key1.knob_state == KNOB_CW)
		{
			if(osc.cursor_b < 127) 	osc.cursor_b+=1;		
			else osc.cursor_b=0;
			key1.knob_state = KNOB_IDLE;
		}
		else if(key1.knob_state == KNOB_CCW)
		{
			if(osc.cursor_b > 0) 	osc.cursor_b-=1;		
			else osc.cursor_b=127;
			key1.knob_state = KNOB_IDLE;
		}
	}			
	if(key1.key_state == KEY_LONG)																											//�������ص�1��MENU_SETT_CURSOR ������ò˵�
	{
		menu = menu_osc_cursor_sub.menu_next;	
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_osc_cursor_sub.menu_level;																	//��ǰ�˵���
	menu1.string_function = menu_osc_cursor_sub.function_name;													//��ǰ�˵���	
}	

/*osc_accuracy����*/
void menu_osc_accuray_func(void)
{
	if(key1.knob_state == KNOB_CW)
	{
		menu = menu_osc_accuracy.menu_next;			
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		menu = &menu_osc_cursor;		
		key1.knob_state = KNOB_IDLE;
	}
	if(key1.key_state == KEY_SHORT)																											//�̰����������ò˵�
	{
		menu = menu_osc_accuracy.menu_sub;				
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//�������ش�������
	{
		menu = &menu_osc_idle;																						     		
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_osc_accuracy.menu_level;																		//��ǰ�˵���
	menu1.string_function = menu_osc_accuracy.function_name;														//��ǰ�˵���		
}
/*osc_accuracy�Ӻ���*/
void menu_osc_accuray_func_sub(void)
{
	if(key1.knob_state == KNOB_CW)
	{
		if(osc.adc_sample_freq_select < ADC_FREQ_MIN)	osc.adc_sample_freq_select += 1;
		else osc.adc_sample_freq_select = 0;
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		if(osc.adc_sample_freq_select > 0)	osc.adc_sample_freq_select -= 1;
		else osc.adc_sample_freq_select = ADC_FREQ_MIN;
		key1.knob_state = KNOB_IDLE;
	}	
	if(key1.key_state == KEY_LONG)																											//�������ص�1��MENU_SETT_ADC_FREQ Ƶ������
	{
		menu = menu_osc_accuracy_sub.menu_next;	
		key1.key_state = KEY_IDLE;
	}			
	if(osc.adc_sample_freq_select == 0) osc.adc_sample_freq = ADC_FREQ_MAX;
	else if(osc.adc_sample_freq_select == 1) osc.adc_sample_freq = ADC_FREQ_1MHZ;
	else if(osc.adc_sample_freq_select == 2) osc.adc_sample_freq = ADC_FREQ_100KHZ;
	else if(osc.adc_sample_freq_select == 3) osc.adc_sample_freq = ADC_FREQ_50KHZ;
	else if(osc.adc_sample_freq_select == 4) osc.adc_sample_freq = ADC_FREQ_10KHZ;	
	Set_adc_sample_freq(TIM2,osc.adc_sample_freq);                              				//���ģʽ��ÿ�ν���������һ��adc�ɼ�Ƶ��
	menu1.menu_level = menu_osc_accuracy_sub.menu_level;																//��ǰ�˵���
	menu1.string_function = menu_osc_accuracy_sub.function_name;												//��ǰ�˵���
}

/*osc_wave����*/
void menu_osc_wave_func(void)
{
	if(key1.knob_state == KNOB_CW)
	{
		menu = menu_osc_wave.menu_next;
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		menu = &menu_osc_accuracy;
		key1.knob_state = KNOB_IDLE;
	}			
	if(key1.key_state == KEY_SHORT)																									//�̰�����MENU_SETT_WAVE ��������˵�
	{
		menu = menu_osc_wave.menu_sub;
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																									//�������ش�������
	{
		menu = &menu_osc_idle;
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_osc_wave.menu_level;																		//��ǰ�˵���
	menu1.string_function = menu_osc_wave.function_name;														//��ǰ�˵���
}	

/*osc_wave�Ӻ���*/
void menu_osc_wave_func_sub(void)
{
	static uint8_t flag_wave=0;
	if(key1.key_state == KEY_SHORT)																									//�̰� ������رղ������
	{
		flag_wave = !flag_wave;
		key1.key_state = KEY_IDLE;
	}			
	if(flag_wave)
	{
		if(key1.knob_state == KNOB_CW)
		{
			if(osc.wave_select < WAVE_MAX-1)	osc.wave_select+=1;
			else osc.wave_select=WAVE_SIN;
			key1.knob_state = KNOB_IDLE;
		}
		else if(key1.knob_state == KNOB_CCW)
		{
			if(osc.wave_select > 0)	osc.wave_select-=1;
			else osc.wave_select=WAVE_NOISE;
			key1.knob_state = KNOB_IDLE;
		}				
		switch(osc.wave_select)
		{
			case(WAVE_SIN):
				Wave_Generator(WAVE_SIN,DAC_VOLTAGE,DAC_Data);		 													//dac1������Ҳ�
				break;
			case(WAVE_TRIANGLE):
				Wave_Generator(WAVE_TRIANGLE,DAC_VOLTAGE,DAC_Data);		 											//dac1������ǲ�
				break;	
			case(WAVE_SAWTOOTH):
				Wave_Generator(WAVE_SAWTOOTH,DAC_VOLTAGE,DAC_Data);		 											//dac1�����ݲ�
				break;	
			case(WAVE_SQUARE):
				Wave_Generator(WAVE_SQUARE,DAC_VOLTAGE,DAC_Data);		 												//dac1�������
				break;	
			case(WAVE_CIRCLE):
				Wave_Generator(WAVE_CIRCLE,DAC_VOLTAGE,DAC_Data);		 												//dac1�����Բ��
				break;			
			case(WAVE_NOISE):																															//����
				Wave_Generator(WAVE_NOISE,DAC_VOLTAGE,DAC_Data);
				break;
			default:
				;
		}	
		DAC_DMACmd(DAC_Channel_1,ENABLE);
	}
	else DAC_DMACmd(DAC_Channel_1,DISABLE);

	if(key1.key_state == KEY_LONG)
	{
		menu = menu_osc_wave_sub.menu_next;
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_osc_wave_sub.menu_level;																		//��ǰ�˵���
	menu1.string_function = menu_osc_wave_sub.function_name;														//��ǰ�˵���	
}

/*halt����*/
void menu_halt_func(void)
{
	if(key1.knob_state == KNOB_CW)
	{
		menu = menu_halt.menu_next;									
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		menu = &menu_osc_wave;	
		key1.knob_state = KNOB_IDLE;
	}				
	if(key1.key_state == KEY_SHORT)																											//�̰�����˯�߲˵�
	{
		osc.sys_pwr+=1;									
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//�������ش�������
	{
		if(osc.sys_pwr == 1) osc.sys_pwr = 0;
		else menu = &menu_osc_idle;
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_halt.menu_level;																						//��ǰ�˵���
	menu1.string_function = menu_halt.function_name;																		//��ǰ�˵���
}

/*osc_flash����*/
void menu_osc_flash_func(void)
{
	if(key1.knob_state == KNOB_CW)
	{
		menu = menu_osc_flash.menu_next;										
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		menu = &menu_halt;
		key1.knob_state = KNOB_IDLE;
	}	
	if(key1.key_state == KEY_SHORT)																											//�̰�����flash�˵�
	{
		menu = menu_osc_flash.menu_sub;	
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//�������ش�������
	{
		menu = &menu_osc_idle;
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_osc_flash.menu_level;
	menu1.string_function = menu_osc_flash.function_name;
}

/*osc_flash�Ӻ���1*/
void menu_osc_flash_func_sub1(void)
{
	static uint8_t flag_flash=0;
	if(flag_flash == 0)																																	//ѡ��save�˵�����ťʧЧ
	{
		if(key1.knob_state == KNOB_CW)																											
		{
			if(osc.flash_function_select < FLASH_MAX-1)	osc.flash_function_select+=1;
			else osc.flash_function_select = FLASH_SAVE;
			key1.knob_state = KNOB_IDLE;
		}
		else if(key1.knob_state == KNOB_CCW)
		{
			if(osc.flash_function_select > 1)	osc.flash_function_select-=1;
			else osc.flash_function_select = FLASH_LIST;
			key1.knob_state = KNOB_IDLE;
		}	
	}	
	else key1.knob_state = KNOB_IDLE;																										//�����������ť������Ҫ�ֶ�����	
	if(key1.key_state == KEY_SHORT)																											//�̰�����ѡ�е�flash�Ӳ˵�{�洢;��ȡ}
	{	
		if(osc.flash_function_select == FLASH_SAVE) 
		{
			if(flag_flash)
			{
				osc.flash_saving = 1;																													//save�˵�ѡ���¶̰������洢�����־
				osc.flash_list_current+=1;																										//����Զ�+1
				if(osc.flash_list_current > FLASH_LIST_SIZE-1) osc.flash_list_current = 0;		//�߽�����
				TIM_Cmd(TIM2, DISABLE); 																											//ֹͣad�ɼ�
				osc.osc_status = 0;																														//osc sacn״̬���ó�"S"
			}
			flag_flash = !flag_flash;																												//ִ���������״̬
		}
		else if(osc.flash_function_select == FLASH_LIST)	menu = menu_osc_flash_sub1.menu_next;
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//�������ص�1��˵�ѡ�����
	{
		osc.flash_function_select = FLASH_SAVE;																						//Ĭ��ѡ��save�˵�
		if(flag_flash == 1)	menu = &menu_osc_flash_sub1;
		else menu = &menu_osc_flash;
		flag_flash = 0;																																		//����
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = (flag_flash==1?menu_osc_flash_sub1.menu_level+1:menu_osc_flash_sub1.menu_level);
	menu1.string_function = menu_osc_flash_sub1.function_name;
}

/*osc_flash�Ӻ���2*/
void menu_osc_flash_func_sub2(void)
{
	if(key1.knob_state == KNOB_CW)																											//�洢����б�ѡ��
	{
		if(osc.flash_list_select < FLASH_LIST_SIZE-1)	osc.flash_list_select+=1;
		else osc.flash_list_select = 0;
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)																								
	{
		if(osc.flash_list_select > 0)	osc.flash_list_select-=1;
		else osc.flash_list_select =FLASH_LIST_SIZE-1;
		key1.knob_state = KNOB_IDLE;
	}	
	if(key1.key_state == KEY_SHORT)
	{		
		osc.flash_reading = 1;																														//�̰�������ȡ�����־	
		osc.flash_function_select = FLASH_SAVE;																						//Ĭ��ѡ��save�˵�
		menu = &menu_osc_idle;																														//���ش�������
		osc.osc_status = 0;																																
		TIM_Cmd(TIM2, DISABLE);  																													//ֹͣad�ɼ�
		key1.key_state = KEY_IDLE;
	}	
	if(key1.key_state == KEY_LONG)																											//����������һ�� �˵���1�� FLASH�˵�
	{	
		menu = &menu_osc_flash_sub1;																															
		key1.key_state = KEY_IDLE;
	}				
	menu1.menu_level = menu_osc_flash_sub2.menu_level;
	menu1.string_function = menu_osc_flash_sub2.function_name;	
}

/*clock����*/
void menu_clock_func(void)
{
	if(key1.knob_state == KNOB_CW)
	{
		menu = menu_clock.menu_next;									
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		menu = &menu_osc_flash;
		key1.knob_state = KNOB_IDLE;
	}	
	if(key1.key_state == KEY_SHORT)																											//�̰�����Clock�˵�
	{
		menu = menu_clock.menu_sub;
		osc.menu_osc = MENU_OSC_CLOCK;																										//����Clock����,�˳�Osc����
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//�������ش�������
	{
		menu = &menu_osc_idle;
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_clock.menu_level;
	menu1.string_function = menu_clock.function_name;	
}

/*clock�Ӻ���*/
void menu_clock_func_sub(void)
{
	signed char clock_setting_conut = 0;
	if(key1.knob_state == KNOB_CW)
	{				
		clock_setting_conut = 1;
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		clock_setting_conut = -1;
		key1.knob_state = KNOB_IDLE;
	}	
	if(key1.key_state == KEY_SHORT)																											//�̰�����˵�
	{
		if(osc.clock_setting < CLOCK_SETTING_MAX-1) osc.clock_setting++;
		else osc.clock_setting = 0;
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//�������ش�������
	{
		osc.menu_osc = MENU_OSC;																													//����Osc����,�˳�Clock����
		osc.clock_setting = CLOCK_SETTING_IDLE;																						//�˳�clock����ģʽ
		menu = menu_clock_sub.menu_next;
		key1.key_state = KEY_IDLE;
	}
	if(osc.clock_setting == CLOCK_SETTING_SECOND) 
	{
		if(osc.clock_time.RTC_Seconds==0 && clock_setting_conut<0)	osc.clock_time.RTC_Seconds =59;
		else osc.clock_time.RTC_Seconds = osc.clock_time.RTC_Seconds+clock_setting_conut;
		if(osc.clock_time.RTC_Seconds > 59) osc.clock_time.RTC_Seconds = 0;
	}
	else if(osc.clock_setting == CLOCK_SETTING_MINUTE) 
	{
		if(osc.clock_time.RTC_Minutes==0 && clock_setting_conut<0)	osc.clock_time.RTC_Minutes =59;
		else osc.clock_time.RTC_Minutes = osc.clock_time.RTC_Minutes+clock_setting_conut;
		if(osc.clock_time.RTC_Minutes > 59) osc.clock_time.RTC_Minutes = 0;
	}
	else if(osc.clock_setting == CLOCK_SETTING_HOUR) 
	{
		if(osc.clock_time.RTC_Hours==0 && clock_setting_conut<0)	osc.clock_time.RTC_Hours =23;
		else osc.clock_time.RTC_Hours = osc.clock_time.RTC_Hours+clock_setting_conut;
		if(osc.clock_time.RTC_Hours > 23) osc.clock_time.RTC_Hours = 0;
	}
	if(osc.clock_setting != CLOCK_SETTING_IDLE)	RTC_Set_Time(osc.clock_time.RTC_Hours,osc.clock_time.RTC_Minutes,osc.clock_time.RTC_Seconds,RTC_H12_AM);	//����ʱ��
	menu1.menu_level = menu_clock_sub.menu_level;
	menu1.string_function = menu_clock_sub.function_name;	
}

/*NRF24L01����*/
void menu_NRF24L01_func(void)
{
	if(key1.knob_state == KNOB_CW)
	{
		menu = menu_NRF24L01.menu_next;											
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		menu = &menu_clock;	
		key1.knob_state = KNOB_IDLE;
	}	
	if(key1.key_state == KEY_SHORT)																											//�̰�����NRF24L01�˵�
	{
		menu = menu_NRF24L01.menu_sub;
		osc.menu_osc = MENU_OSC_NRF24L01;																									//����NRF24L01����,�˳�Osc����
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//�������ش�������
	{
		menu = &menu_osc_idle;
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_NRF24L01.menu_level;
	menu1.string_function = menu_NRF24L01.function_name;	
}

/*NRF24L01�Ӻ���*/
void menu_NRF24L01_func_sub1(void)
{
	if(key1.knob_state == KNOB_CW)
	{	
		NRF24L01_par1.NRF24L01_select = NRF24L01_par2.NRF24L01_select;
		NRF24L01_par2.NRF24L01_select = !NRF24L01_par1.NRF24L01_select;
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		NRF24L01_par1.NRF24L01_select = NRF24L01_par2.NRF24L01_select;
		NRF24L01_par2.NRF24L01_select = !NRF24L01_par1.NRF24L01_select;		
		key1.knob_state = KNOB_IDLE;
	}	
	if(key1.key_state == KEY_SHORT)																											//�̰�
	{
		if(NRF24L01_par1.NRF24L01_select == 0)	menu_NRF24L01_sub1.func = menu_NRF24L01_func_sub1_1;
		else if (NRF24L01_par2.NRF24L01_select == 0)	menu_NRF24L01_sub1.func = menu_NRF24L01_func_sub1_2;			
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//�������ش�������
	{
		osc.menu_osc = MENU_OSC;																													//����Osc����,�˳�Clock����
		menu = menu_NRF24L01_sub1.menu_next;
		menu_NRF24L01_sub1.func = menu_NRF24L01_func_sub1;
		key1.key_state = KEY_IDLE;
	}
	menu1.menu_level = menu_NRF24L01_sub1.menu_level;
	menu1.string_function = menu_NRF24L01_sub1.function_name;
}

/********************************************************
�������ܣ�NRF24L01��������                      
��ڲ�����dev:NRF24L01�豸
					NRF24L01_par1,NRF24L01_par2
					buff:Ҫ���͵�����
					n:������ʼλ��
����  ֵ����
*********************************************************/
void TX_Bytes(NRF24L01_DEV dev,uint8_t *buff,uint8_t n)
{
	uint8_t i;
	for(i=0;i<32;i++)
	{
		if(i+n<dev.NRF24L01_data_size)	dev.NRF24L01_buff[i] = buff[i+n];
	}
	NRF24L01_TxPacket(dev.NRF24L01_spi,dev.NRF24L01_buff);	
}

/*NRF24L01�Ӻ���1_1*/
void menu_NRF24L01_func_sub1_1(void)
{
	static uint8_t j=0;
	if(key1.knob_state == KNOB_CW)
	{	
		NRF24L01_par1.NRF24L01_mode = !NRF24L01_par1.NRF24L01_mode;
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		NRF24L01_par1.NRF24L01_mode = !NRF24L01_par1.NRF24L01_mode;
		key1.knob_state = KNOB_IDLE;
	}	
	if(key1.key_state == KEY_SHORT)																											//�̰�
	{
		if(NRF24L01_par1.NRF24L01_mode == NRF24L01_MODE_TX)	
		{
			if(NRF24L01_par1.NRF24L01_mode == NRF24L01_MODE_TX)	 NRF24L01_par1.NRF24L01_transmit_done = 1;		//��������
			NRF24L01_TX_Mode(NRF24L01_par1.NRF24L01_spi);
		}
		else NRF24L01_RX_Mode(NRF24L01_par1.NRF24L01_spi);																				
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//����������һ���˵�
	{												
		menu_NRF24L01_sub1.func = menu_NRF24L01_func_sub1;
		key1.key_state = KEY_IDLE;
	}	
	
	if(NRF24L01_par1.NRF24L01_mode == NRF24L01_MODE_TX && NRF24L01_par1.NRF24L01_transmit_done)				//�������
	{
		TX_Bytes(NRF24L01_par1,osc.display_data,j);
		j+=32;
		if(j>NRF24L01_par1.NRF24L01_data_size-1) 																					//������һ��
		{
			j=0;	
			NRF24L01_par1.NRF24L01_transmit_done = 0;																				//ֹͣ����
		}		
	}
}

/*NRF24L01�Ӻ���1_2*/
void menu_NRF24L01_func_sub1_2(void)
{
	uint8_t TX_BUFF[32]= {0x47};
	if(key1.knob_state == KNOB_CW)
	{	
		NRF24L01_par2.NRF24L01_mode = !NRF24L01_par2.NRF24L01_mode;
		key1.knob_state = KNOB_IDLE;
	}
	else if(key1.knob_state == KNOB_CCW)
	{
		NRF24L01_par2.NRF24L01_mode = !NRF24L01_par2.NRF24L01_mode;
		key1.knob_state = KNOB_IDLE;
	}	
	
	if(key1.key_state == KEY_SHORT)																											//�̰�
	{
		NRF24L01_par2.NRF24L01_err = 0x00;
		if(NRF24L01_par2.NRF24L01_mode == NRF24L01_MODE_TX)	NRF24L01_TX_Mode(NRF24L01_par2.NRF24L01_spi);
		else NRF24L01_RX_Mode(NRF24L01_par2.NRF24L01_spi);		
		if(NRF24L01_par2.NRF24L01_mode == NRF24L01_MODE_TX) NRF24L01_par2.NRF24L01_err = NRF24L01_TxPacket(NRF24L01_par2.NRF24L01_spi,NRF24L01_par2.NRF24L01_buff);			
		key1.key_state = KEY_IDLE;
	}
	if(key1.key_state == KEY_LONG)																											//����������һ���˵�
	{
		menu_NRF24L01_sub1.func = menu_NRF24L01_func_sub1;
		key1.key_state = KEY_IDLE;
	}	
}

void Menu(void)
{
	Key_Scan(0,key1);                                   																//ģʽ�����ΰ�����Ч  ��ȡkey_statusֵ
	menu->func();	
}




//void Menu(void)
//{
//	static uint8_t flag_menu=0b00000000;																								//
//																																											//bit1�ǲ������ʹ��
//																																											//bit4��POSITION����ѡ��
//																																											//bit5��POSITION����ʱ��ʾʹ��
//	static uint32_t position_offset_delay=0;																						//������¼ƫ�÷���ͣ��ʱ��
//	signed char clock_setting_conut=0;																									//clock�˵����ü���		�������ж�ʱ������char		
//	Key_Scan(0,key1);                                   																//ģʽ�����ΰ�����Ч  ��ȡkey_statusֵ
//	switch(menu1.menu_status)
//	{
///********MENU1-1*********/
//		case (MENU_SETT_X_DIV):																														//menu1-1 MENU_SETT_Zoom
//			if(key1.knob_state == KNOB_CW)
//			{
//				menu1.menu_status = MENU_SETT_CURSOR;											
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				menu1.menu_status = MENU_NRF24L01;	
//				key1.knob_state = KNOB_IDLE;
//			}
//			if(key1.key_state == KEY_SHORT)
//			{
//				menu1.menu_status = MENU_LEVEL_1+MENU_SETT_X_DIV;				
//				key1.key_state = KEY_IDLE;
//			}
//			else if(key1.key_state == KEY_LONG)
//			{
//				menu1.menu_status = MENU_IDLE;				
//				key1.key_state = KEY_IDLE;				
//			}
//			menu1.menu_level = 1;
//			menu1.string_function = MENU_FUNCTION[1];
//			break;
//		case (MENU_LEVEL_1+MENU_SETT_X_DIV):																							//menu1-1-1 MENU_SETT_Zoom
//			if(key1.knob_state == KNOB_CW)
//			{
//				if(osc.horizontal_div < 10) osc.horizontal_div +=1;	
//				else osc.horizontal_div=1;
//				key1.knob_state = KNOB_IDLE;			
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				if(osc.horizontal_div > 1)	osc.horizontal_div-=1;
//					else osc.horizontal_div =10;	
//				key1.knob_state = KNOB_IDLE;
//			}
//			if(key1.key_state == KEY_SHORT)																									//�̰�������ʾ��ʼλ�ò˵�
//			{
//				menu1.menu_status = MENU_LEVEL_1+MENU_SETT_POSITION;
//				key1.key_state = KEY_IDLE;
//			}			
//			
//			if(key1.key_state == KEY_LONG)																									//�������ص�1��MENU_SETT_X_DIV����ˮƽ���Ų˵�
//			{
//				menu1.menu_status = MENU_SETT_X_DIV;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 2;
//			menu1.string_function = MENU_FUNCTION[1];
//			break;
///********MENU1-2*********/			
//		case  (MENU_SETT_CURSOR):																													//menu1-2 MENU_SETT_CURSOR
//			if(key1.knob_state == KNOB_CW)
//			{
//				menu1.menu_status = MENU_SETT_ADC_FREQ;											
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				menu1.menu_status = MENU_SETT_X_DIV;	
//				key1.knob_state = KNOB_IDLE;
//			}
//			if(key1.key_state == KEY_SHORT)																									//�̰����������ò˵�
//			{
//				menu1.menu_status =MENU_LEVEL_1+MENU_SETT_CURSOR;								
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																									//�������ش�������
//			{
//				menu1.menu_status = MENU_IDLE;        
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 1;
//			menu1.string_function = MENU_FUNCTION[2];
//			break;
//		case (MENU_LEVEL_1+MENU_SETT_CURSOR):																							//menu1-2-1 MENU_SETT_CURSOR
//				if(key1.key_state == KEY_SHORT)																								//�̰��л���һ�����
//				{				
//					key1.key_state = KEY_IDLE;
//					REVERSEBIT(flag_menu,1);
//				}
//				if(READBIT(flag_menu,1) == 0)																									//���aѡ��
//				{
//					osc.cursor_select = 0;																					
//					if(key1.knob_state == KNOB_CW)
//					{
//						if(osc.cursor_a < 127) 	osc.cursor_a+=1;		
//						else osc.cursor_a=0;
//						key1.knob_state = KNOB_IDLE;
//					}
//					else if(key1.knob_state == KNOB_CCW)
//					{
//						if(osc.cursor_a > 0) 	osc.cursor_a-=1;		
//						else osc.cursor_a=127;
//						key1.knob_state = KNOB_IDLE;
//					}
//				}
//				else if	(READBIT(flag_menu,1) == 1)																						//���bѡ��
//				{
//					osc.cursor_select = 1;																					
//					if(key1.knob_state == KNOB_CW)
//					{
//						if(osc.cursor_b < 127) 	osc.cursor_b+=1;		
//						else osc.cursor_b=0;
//						key1.knob_state = KNOB_IDLE;
//					}
//					else if(key1.knob_state == KNOB_CCW)
//					{
//						if(osc.cursor_b > 0) 	osc.cursor_b-=1;		
//						else osc.cursor_b=127;
//						key1.knob_state = KNOB_IDLE;
//					}
//				}			
//				if(key1.key_state == KEY_LONG)																								//�������ص�1��MENU_SETT_CURSOR ������ò˵�
//				{
//					menu1.menu_status = MENU_SETT_CURSOR;
//					key1.key_state = KEY_IDLE;
//				}
//				menu1.menu_level = 2;
//			break;
///********MENU1-3*********/
//		case (MENU_SETT_ADC_FREQ):																												//menu1-3 MENU_SETT_ADC_FREQ
//			if(key1.knob_state == KNOB_CW)
//			{
//				menu1.menu_status = MENU_SETT_WAVE;											
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				menu1.menu_status = MENU_SETT_CURSOR;	
//				key1.knob_state = KNOB_IDLE;
//			}	
//			if(key1.key_state == KEY_SHORT)																									//�̰�����adc�ɼ�Ƶ�����ò˵�
//			{
//				menu1.menu_status = MENU_LEVEL_1+MENU_SETT_ADC_FREQ;																				
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																									//�������ش�������
//			{
//				menu1.menu_status = MENU_IDLE;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 1;
//			menu1.string_function = MENU_FUNCTION[3];
//			break;
//		case (MENU_LEVEL_1+MENU_SETT_ADC_FREQ):																						//menu1-3-1	MENU_SETT_ADC_FREQ adc�ɼ�Ƶ�����ò˵�
//			if(key1.knob_state == KNOB_CW)
//			{
//				if(osc.adc_sample_freq_select < ADC_FREQ_MIN)	osc.adc_sample_freq_select += 1;
//				else osc.adc_sample_freq_select = 0;
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				if(osc.adc_sample_freq_select > 0)	osc.adc_sample_freq_select -= 1;
//				else osc.adc_sample_freq_select = ADC_FREQ_MIN;
//				key1.knob_state = KNOB_IDLE;
//			}	
//			if(key1.key_state == KEY_LONG)																									//�������ص�1��MENU_SETT_ADC_FREQ Ƶ������
//			{
//				menu1.menu_status = MENU_SETT_ADC_FREQ;
//				key1.key_state = KEY_IDLE;
//			}			
//			if(osc.adc_sample_freq_select == 0) osc.adc_sample_freq = ADC_FREQ_MAX;
//			else if(osc.adc_sample_freq_select == 1) osc.adc_sample_freq = ADC_FREQ_1MHZ;
//			else if(osc.adc_sample_freq_select == 2) osc.adc_sample_freq = ADC_FREQ_100KHZ;
//			else if(osc.adc_sample_freq_select == 3) osc.adc_sample_freq = ADC_FREQ_50KHZ;
//			else if(osc.adc_sample_freq_select == 4) osc.adc_sample_freq = ADC_FREQ_10KHZ;	
//			Set_adc_sample_freq(TIM2,osc.adc_sample_freq);                              		//���ģʽ��ÿ�ν���������һ��adc�ɼ�Ƶ��
//			menu1.menu_level = 2;
//			break;
///********MENU1-4*********/																														//menu1-4	MENU_SETT_WAVE
//		case (MENU_SETT_WAVE):																														
//			if(key1.knob_state == KNOB_CW)
//			{
//				menu1.menu_status = MENU_HALT;											
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				menu1.menu_status = MENU_SETT_ADC_FREQ;	
//				key1.knob_state = KNOB_IDLE;
//			}			
//			if(key1.key_state == KEY_SHORT)																									//�̰�����MENU_SETT_WAVE ��������˵�
//			{
//				menu1.menu_status = MENU_LEVEL_1+MENU_SETT_WAVE;
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																									//�������ش�������
//			{
//				menu1.menu_status = MENU_IDLE;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 1;
//			menu1.string_function = MENU_FUNCTION[4];
//			break;
//		case (MENU_LEVEL_1+MENU_SETT_WAVE):																								//menu1-4-1 MENU_SETT_WAVE �����������
//			if(key1.key_state == KEY_SHORT)																									//�̰� ������رղ������
//			{
//				REVERSEBIT(flag_menu,1);
//				key1.key_state = KEY_IDLE;
//			}			
//		
//			if(READBIT(flag_menu,1))
//			{
//				if(key1.knob_state == KNOB_CW)
//				{
//					if(osc.wave_select < WAVE_MAX-1)	osc.wave_select+=1;
//					else osc.wave_select=WAVE_SIN;
//					key1.knob_state = KNOB_IDLE;
//				}
//				else if(key1.knob_state == KNOB_CCW)
//				{
//					if(osc.wave_select > 0)	osc.wave_select-=1;
//					else osc.wave_select=WAVE_NOISE;
//					key1.knob_state = KNOB_IDLE;
//				}				
//				switch(osc.wave_select)
//				{
//					case(WAVE_SIN):
//						Wave_Generator(WAVE_SIN,DAC_VOLTAGE,DAC_Data);		 													//dac1������Ҳ�
//						break;
//					case(WAVE_TRIANGLE):
//						Wave_Generator(WAVE_TRIANGLE,DAC_VOLTAGE,DAC_Data);		 											//dac1������ǲ�
//						break;	
//					case(WAVE_SAWTOOTH):
//						Wave_Generator(WAVE_SAWTOOTH,DAC_VOLTAGE,DAC_Data);		 											//dac1�����ݲ�
//						break;	
//					case(WAVE_SQUARE):
//						Wave_Generator(WAVE_SQUARE,DAC_VOLTAGE,DAC_Data);		 												//dac1�������
//						break;	
//					case(WAVE_CIRCLE):
//						Wave_Generator(WAVE_CIRCLE,DAC_VOLTAGE,DAC_Data);		 												//dac1�����Բ��
//						break;			
//					case(WAVE_NOISE):																															//����
//						Wave_Generator(WAVE_NOISE,DAC_VOLTAGE,DAC_Data);
//						break;
//					default:
//						;
//				}	
//				DAC_DMACmd(DAC_Channel_1,ENABLE);
//			}
//			else DAC_DMACmd(DAC_Channel_1,DISABLE);
//	
//			if(key1.key_state == KEY_LONG)
//			{
//				menu1.menu_status = MENU_SETT_WAVE;									
//				key1.key_state = KEY_IDLE;
//			}
//		menu1.menu_level = 2;
//			break;
///*********MENU1-1-2**********/																														//menu1-1-2 MENU_SETT_POSITION
//		case (MENU_LEVEL_1+MENU_SETT_POSITION):
//			if(key1.knob_state == KNOB_CW)																											//��ť�ı���ʾ�Ŀ�ʼλ��
//			{
//				if(osc.position+osc.oled->width*osc.horizontal_div< SAMPLE_DATA_SIZE)osc.position+=(1*osc.horizontal_div);
//				else osc.position = SAMPLE_DATA_SIZE-osc.oled->width*osc.horizontal_div;
//				position_offset_delay = tickCnt;
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				if(osc.position > osc.horizontal_div) osc.position-=(1*osc.horizontal_div);
//				else osc.position = 0;
//				position_offset_delay = tickCnt;
//				key1.knob_state = KNOB_IDLE;
//			}			
//			if(key1.key_state == KEY_SHORT)																											//�̰�����X_DIV�˵�
//			{
//				menu1.menu_status = MENU_LEVEL_1+MENU_SETT_X_DIV;
//				osc.position_select_countdown_state =0;
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																											//�������ص�1�� X_DIV�˵�
//			{
//				menu1.menu_status = MENU_SETT_X_DIV;
//				osc.position_select_countdown_state =0;
//				key1.key_state = KEY_IDLE;
//			}
//			if(position_offset_delay - tickCnt == 0)																						//λ�ý���������ʱ��ʾʹ��
//			{
//				osc.position_select_countdown_state = 1;
//			}
//			else if((position_offset_delay+1000-tickCnt)/10 <=20)																//λ�ý���������ʱ��ʾʧ��
//			{
//				osc.position_select_countdown_state =0;
//			}
//			menu1.menu_level = 2;
//			menu1.string_function = MENU_FUNCTION[5];
//			break;	
///*******MENU1-6*******/																																		//menu1-6 MENU_HALT 
//		case (MENU_HALT):																												
//			if(key1.knob_state == KNOB_CW)
//			{
//				menu1.menu_status = MENU_FLASH;											
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				menu1.menu_status = MENU_SETT_WAVE;	
//				key1.knob_state = KNOB_IDLE;
//			}				
//			if(key1.key_state == KEY_SHORT)																											//�̰�����˯�߲˵�
//			{
//				menu1.menu_status = MENU_LEVEL_1+MENU_HALT;
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																											//�������ش�������
//			{
//				menu1.menu_status = MENU_IDLE;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 1;
//			menu1.string_function = MENU_FUNCTION[6];
//			break;
//		case (MENU_LEVEL_1+MENU_HALT):																												//����˯�߲˵�
//			if(key1.key_state == KEY_SHORT)
//			{	
//				osc.sys_pwr =2;																																		//�̰�˯��
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																											//�������ص�1��halt�˵�
//			{
//				menu1.menu_status = MENU_HALT;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 2;
//			break;		

///*******MENU1-7*******/																																		//��1��flash�˵�
//		case (MENU_FLASH):		
//			if(key1.knob_state == KNOB_CW)
//			{
//				menu1.menu_status = MENU_CLOCK;											
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				menu1.menu_status = MENU_HALT;	
//				key1.knob_state = KNOB_IDLE;
//			}	
//			if(key1.key_state == KEY_SHORT)																											//�̰�����flash�˵�
//			{
//				menu1.menu_status = MENU_LEVEL_1+MENU_FLASH;
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																											//�������ش�������
//			{
//				menu1.menu_status = MENU_IDLE;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 1;
//			menu1.string_function = MENU_FUNCTION[7];
//			break;
///*******MENU1-7-1*******/																																	//�洢���б��˵�ѡ�����
//		case (MENU_LEVEL_1+MENU_FLASH):
//			if(key1.knob_state == KNOB_CW)																											
//			{
//				if(osc.flash_function_select < FLASH_MAX-1)	osc.flash_function_select+=1;
//				else osc.flash_function_select = FLASH_SAVE;
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				if(osc.flash_function_select > 1)	osc.flash_function_select-=1;
//				else osc.flash_function_select = FLASH_LIST;
//				key1.knob_state = KNOB_IDLE;
//			}				
//			if(key1.key_state == KEY_SHORT)																											//�̰�����ѡ�е�flash�Ӳ˵�{�洢;��ȡ}
//			{	
//				menu1.menu_status = MENU_LEVEL_2+MENU_FLASH+osc.flash_function_select;																															
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																											//�������ص�1��˵�ѡ�����
//			{
//				menu1.menu_status = MENU_FLASH;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 2;
//			break;	
///*******MENU2-7-1*******/			
//		case (MENU_LEVEL_2+MENU_FLASH+FLASH_SAVE):
//			if(key1.key_state == KEY_SHORT)
//			{	
//				osc.flash_saving = 1;																															//�̰������洢��־
//				osc.flash_list_current+=1;																												//����Զ�+1
//				if(osc.flash_list_current > FLASH_LIST_SIZE-1) osc.flash_list_current = 0;
//				TIM_Cmd(TIM2, DISABLE); 
//				osc.osc_status = 0;
//				menu1.menu_status = MENU_LEVEL_1+MENU_FLASH;																															
//				key1.key_state = KEY_IDLE;
//			}			
//			if(key1.key_state == KEY_LONG)																											//����������һ�� �˵���1�� FLASH�˵�
//			{
//				menu1.menu_status = MENU_LEVEL_1+MENU_FLASH;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 3;					
//			break;
///*******MENU2-7-1*******/		
//		case (MENU_LEVEL_2+MENU_FLASH+FLASH_LIST):
//			if(key1.knob_state == KNOB_CW)																											//�洢����б�ѡ��
//			{
//				if(osc.flash_list_select < FLASH_LIST_SIZE-1)	osc.flash_list_select+=1;
//				else osc.flash_list_select = 0;
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)																								
//			{
//				if(osc.flash_list_select > 0)	osc.flash_list_select-=1;
//				else osc.flash_list_select =FLASH_LIST_SIZE-1;
//				key1.knob_state = KNOB_IDLE;
//			}	
//			if(key1.key_state == KEY_SHORT)
//			{		
//				osc.flash_reading = 1;																														//�̰�������ȡ�����־
//				menu1.menu_status = MENU_IDLE;																										//���ش�������
//				osc.osc_status = 0;																																
//				RESETBIT(flag_menu,0);
//				TIM_Cmd(TIM2, DISABLE);  																													//ֹͣad�ɼ�
//				key1.key_state = KEY_IDLE;
//			}	
//			if(key1.key_state == KEY_LONG)																											//����������һ�� �˵���1�� FLASH�˵�
//			{	
//				menu1.menu_status = MENU_LEVEL_1+MENU_FLASH;																															
//				key1.key_state = KEY_IDLE;
//			}				
//			menu1.menu_level = 3;
//			break;
///*******MENU1-8*******/																																		//��1��Clock�˵�
//		case (MENU_CLOCK):		
//			if(key1.knob_state == KNOB_CW)
//			{
//				menu1.menu_status = MENU_NRF24L01;											
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				menu1.menu_status = MENU_FLASH;	
//				key1.knob_state = KNOB_IDLE;
//			}	
//			if(key1.key_state == KEY_SHORT)																											//�̰�����Clock�˵�
//			{
//				menu1.menu_status = MENU_LEVEL_1+MENU_CLOCK;
//				osc.menu_osc = MENU_OSC_CLOCK;																										//����Clock����,�˳�Osc����
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																											//�������ش�������
//			{
//				menu1.menu_status = MENU_IDLE;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 1;
//			menu1.string_function = MENU_FUNCTION[8];
//			break;			
///*******MENU1-8-1*******/																																	//Clock�˵�
//		case (MENU_LEVEL_1+MENU_CLOCK):		
//			if(key1.knob_state == KNOB_CW)
//			{				
//				clock_setting_conut = 1;
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				clock_setting_conut = -1;
//				key1.knob_state = KNOB_IDLE;
//			}	
//			if(key1.key_state == KEY_SHORT)																											//�̰�����˵�
//			{
//				if(osc.clock_setting < CLOCK_SETTING_MAX-1) osc.clock_setting++;
//				else osc.clock_setting = 0;
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																											//�������ش�������
//			{
//				osc.menu_osc = MENU_OSC;																													//����Osc����,�˳�Clock����
//				osc.clock_setting = CLOCK_SETTING_IDLE;																						//�˳�clock����ģʽ
//				menu1.menu_status = MENU_CLOCK;
//				key1.key_state = KEY_IDLE;
//			}
//			if(osc.clock_setting == CLOCK_SETTING_SECOND) 
//			{
//				if(osc.clock_time.RTC_Seconds==0 && clock_setting_conut<0)	osc.clock_time.RTC_Seconds =59;
//				else osc.clock_time.RTC_Seconds = osc.clock_time.RTC_Seconds+clock_setting_conut;
//				if(osc.clock_time.RTC_Seconds > 59) osc.clock_time.RTC_Seconds = 0;
//			}
//			else if(osc.clock_setting == CLOCK_SETTING_MINUTE) 
//			{
//				if(osc.clock_time.RTC_Minutes==0 && clock_setting_conut<0)	osc.clock_time.RTC_Minutes =59;
//				else osc.clock_time.RTC_Minutes = osc.clock_time.RTC_Minutes+clock_setting_conut;
//				if(osc.clock_time.RTC_Minutes > 59) osc.clock_time.RTC_Minutes = 0;
//			}
//			else if(osc.clock_setting == CLOCK_SETTING_HOUR) 
//			{
//				if(osc.clock_time.RTC_Hours==0 && clock_setting_conut<0)	osc.clock_time.RTC_Hours =23;
//				else osc.clock_time.RTC_Hours = osc.clock_time.RTC_Hours+clock_setting_conut;
//				if(osc.clock_time.RTC_Hours > 23) osc.clock_time.RTC_Hours = 0;
//			}
//			if(osc.clock_setting != CLOCK_SETTING_IDLE)	RTC_Set_Time(osc.clock_time.RTC_Hours,osc.clock_time.RTC_Minutes,osc.clock_time.RTC_Seconds,RTC_H12_AM);	//����ʱ��
//			menu1.menu_level = 2;
//			break;			
///*******MENU1-9*******/																																		//��1��NRF24L01�˵�
//		case (MENU_NRF24L01):		
//			if(key1.knob_state == KNOB_CW)
//			{
//				menu1.menu_status = MENU_SETT_X_DIV;											
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				menu1.menu_status = MENU_CLOCK;	
//				key1.knob_state = KNOB_IDLE;
//			}	
//			if(key1.key_state == KEY_SHORT)																											//�̰�����NRF24L01�˵�
//			{
//				menu1.menu_status = MENU_LEVEL_1+MENU_NRF24L01;
//				osc.menu_osc = MENU_OSC_NRF24L01;																									//����NRF24L01����,�˳�Osc����
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																											//�������ش�������
//			{
//				menu1.menu_status = MENU_IDLE;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 1;
//			menu1.string_function = MENU_FUNCTION[9];
//			break;	
///*******MENU1-9-1*******/																																	//NRF24L01�˵�
//		case (MENU_LEVEL_1+MENU_NRF24L01):		
//			if(key1.knob_state == KNOB_CW)
//			{				
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				key1.knob_state = KNOB_IDLE;
//			}	
//			if(key1.key_state == KEY_SHORT)																											//�̰�
//			{
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																											//�������ش�������
//			{
//				osc.menu_osc = MENU_OSC;																													//����Osc����,�˳�Clock����
//				menu1.menu_status = MENU_NRF24L01;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 2;
//			break;			
///********MENU0*********/
//		case (MENU_IDLE):																																			//menu0 MENU_IDLE �������棬Ĭ���ǲ˵���0��
//			if(key1.knob_state == KNOB_CW)
//			{
//				if(osc.trigger_voltage < oled_par.heigh-1) osc.trigger_voltage+=1;
//				else 
//				{
//					osc.trigger_voltage = oled_par.heigh-1;
//					osc.trigger_function = 1;																												//������������
//				}
//				key1.knob_state = KNOB_IDLE;
//			}
//			else if(key1.knob_state == KNOB_CCW)
//			{
//				if(osc.trigger_voltage > 0) osc.trigger_voltage-=1;
//				else 
//				{
//					osc.trigger_voltage = 0;
//					osc.trigger_function = 0;																												//�رմ�������
//				}
//				key1.knob_state = KNOB_IDLE;
//			}						
//			if(key1.key_state == KEY_SHORT)																											//���������¶̰�ֹͣad�ɼ�
//			{
//				if(osc.osc_status == 0)
//				{
//					TIM_Cmd(TIM2, ENABLE);	
//					osc.osc_status = 1;
//				}
//				else
//				{
//					TIM_Cmd(TIM2, DISABLE);  																											
//					osc.osc_status = 0;																															//�ٴζ̰�����ad�ɼ�
//				}
//				key1.key_state = KEY_IDLE;
//			}
//			if(key1.key_state == KEY_LONG)																											//�������泤������˵���1�� Ĭ��ѡ��Zoom�˵�
//			{
//				menu1.menu_status = MENU_SETT_X_DIV;
//				key1.key_state = KEY_IDLE;
//			}
//			menu1.menu_level = 0;																																//��ǰ�˵���
//			menu1.string_function = MENU_FUNCTION[0];																						//��ǰ�˵���
//			break;			
//		default:
//			menu1.menu_status = MENU_IDLE;
//			break;
//	}
//}
