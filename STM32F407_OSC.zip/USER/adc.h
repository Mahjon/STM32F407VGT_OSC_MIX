#ifndef _ADC_H
#define _ADC_H

#include "stm32f4xx.h"
void ADC_Initi(void);
void ADC1_START(void);
uint8_t Get_ADC1_Value(void);
void Get_ad_data(void);
uint16_t Get_ADC1_Value_Ave(void);
extern uint16_t ad_data[128];
#endif
