#ifndef _TIMER_TASK_H
#define _TIMER_TASK_H
#include "sys.h"

void user_task1(void);
void user_task2(void);

#endif
