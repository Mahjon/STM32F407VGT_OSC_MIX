#ifndef _INCLUDES_H
#define _INCLUDES_H
#include "led.h"
#include "delay.h"
#include "led.h"
#include "adc.h"
#include "timer.h"
#include "pwm.h"
#include "osc.h"
#include "key.h"
#include "oled.h"
#include "dac.h"
#include "menu.h"
#include "rtc.h"
#include "rng.h"
#include "wkup.h"
#include "lcd.h"
#include "w25q16.h"
#include "timer_task.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "icon.h"
#include "stdint.h"
#include "iwdg.h"
#include "bmp280.h"
#include "nrf24l01.h"
#include "onchipflash.h"


#endif