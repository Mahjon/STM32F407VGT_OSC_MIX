#include "wkup.h"
#include "delay.h"
void Sys_Enter_Standby(void)
{
	while(WK_UP);																					//�������ͷŲ�
	RCC_AHB1PeriphResetCmd(0x01f,ENABLE);  								//��λ����IO��GPIOA ~GPIOE
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR,ENABLE);		//ʹ��pwrʱ��
	PWR_BackupAccessCmd(ENABLE);													//ʹ�ܺ��������
	
	RTC_ITConfig(RTC_IT_TS | RTC_IT_WUT | RTC_IT_ALRA | RTC_IT_ALRB,DISABLE); //�ر��й�RTC��ص������ж�
	RTC_ClearITPendingBit(RTC_IT_TS | RTC_IT_WUT | RTC_IT_ALRA | RTC_IT_ALRB);//����й�RTC��ص������жϱ�־
	
	PWR_ClearFlag(PWR_FLAG_WU);														//���Wakeup��־
	PWR_WakeUpPinCmd(ENABLE);															//����WKUP(PA0)����ʹ��
	PWR_EnterSTANDBYMode();																//�������ģʽ
}

uint8_t Check_WKUP(void)
{
	uint8_t	t=0;
	uint8_t tx=0;
	while(1)
	{
		if(WK_UP) 
		{
			t++;
			tx=0;
		}
		else
		{
			tx++;
			if(tx>3)
			{
				return 0;
			}
		}
		delay_ms(30);
		if(t>=100)								//����3s��
		{
			return 1;
		}
	}
}

/*�ⲿ�ж�*/
//void EXITI0_IRQHandler(void)
//{
//	EXTI_ClearITPendingBit(EXTI_Line0);
//	if(Check_WKUP())
//	{
//		Sys_Enter_Standby();
//	}
//}

void WKUP_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
	RCC_AHB2PeriphClockCmd(RCC_APB2Periph_SYSCFG,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd =	GPIO_PuPd_DOWN;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	if(Check_WKUP()==0)															//ÿ��WKUP�������������ߣ����ǰ���3s���ϲſ���
	{
		Sys_Enter_Standby();
	}
//	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA,EXTI_PinSource0);	
	
//	EXTI_InitStructure.EXTI_Line = EXTI_Line0;
//	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
//	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//	EXTI_Init(&EXTI_InitStructure);
//	
//	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_Init(&NVIC_InitStructure);
}