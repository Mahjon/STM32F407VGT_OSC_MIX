#include "timer.h"
#include "misc.h"
#include "led.h"
#include "stm32f4xx_tim.h"
#define TIMER_NUM  3
volatile u32 tickCnt=0;


void TIME3_Initi(void)
{ 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);//ʹ��ʱ��
	//Tout = ((arr+1)*(psc+1))/Tclk=10*8400/84Mhz=1ms,Tclk=APB1*2=42*2=84Mhz
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;//
	TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up;//���ϼ�����ʽ
	TIM_TimeBaseStructure.TIM_Period=9;//�Զ���װ������arr+1
	TIM_TimeBaseStructure.TIM_Prescaler=8399;//��Ƶϵ��psc+1
	//TIM_TimeBaseStructure.TIM_RepetitionCounter=;//ͨ�ö�ʱ����Ч����TIME1��TIME8��Ч
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseStructure);//װ��TIM3
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);//ָ��TIM3�жϸ���
	TIM_Cmd(TIM3,ENABLE);//����TIM3
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel=TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;//��ռ���ȼ�
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=2;//��Ӧ���ȼ�
	NVIC_Init(&NVIC_InitStructure);
}

void TIME4_Initi(uint16_t arr,uint16_t psc) 
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);
	
	TIM_TimeBaseInitStructure.TIM_Period=arr;
	TIM_TimeBaseInitStructure.TIM_Prescaler=psc;
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Down;
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1;//APB1=42Mhz
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseInitStructure);
	TIM_SelectOutputTrigger(TIM4,TIM_TRGOSource_Update);
	TIM_Cmd(TIM4,ENABLE);
}

void TIM3_IRQHandler()
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET)
	{
		LED2=!LED2;
		tickCnt++;
		if(tickCnt>=4294967295) tickCnt=0;
	}
	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
}

typedef struct 
{
	uint8_t state;
	uint8_t mode;
	uint32_t match;
	uint32_t period;
	callback argv;
}softTimer;

typedef enum
{
	Mode_Once=0,
	Mode_Periodic
}timerMode;

typedef enum
{
	State_Stopped=0,
	State_Running,
	State_Timeout
}timerState;

static softTimer timer[TIMER_NUM];//��ʱ������

void Timer_Initi(void)
{
	uint8_t i;
	
	for(i=0;i<TIMER_NUM;i++)
	{
		timer[i].argv=(void*)0;
		timer[i].match=0;
		timer[i].mode=0;
		timer[i].period=0;
		timer[i].state=0;
	}
}

void Timer_Config(uint8_t num,callback p ,uint8_t mode,uint32_t period)
{
	assert_param(num>TIMER_NUM);
	timer[num].argv=p;
	timer[num].period=period;
	timer[num].mode=mode;
	timer[num].state=State_Running;
	timer[num].match=tickCnt+period;
}
void Timer_Update(void)
{
	uint8_t i;
	callback p;
	for(i=0;i<TIMER_NUM;i++)
	{
		switch(timer[i].state)
		{
			case State_Stopped:
				break;
			case State_Running:
				if(timer[i].match<=tickCnt)
					{
						timer[i].state=State_Timeout;
						p=timer[i].argv;
						p();
					}
				break;
			case State_Timeout:
				if(timer[i].mode==Mode_Once)
					timer[i].state=State_Stopped;
				else 
				{
					timer[i].match=tickCnt+timer[i].period;
					timer[i].state=State_Running;
				}
				break;
			default:
				break;
		}
	}
}
