#ifndef __HARDIIC_H
#define __HARDIIC_H
#include "sys.h"

#define	I2C1_SOFT 0           //0:ʹ��Ӳ��I2C1 1:ʹ������ģ��I2C
#define I2C2_SOFT 0						//0:ʹ��Ӳ��I2C2 1:ʹ������ģ��I2C
/*I2C1*/
//PB9 OLED_EN;
//PB8 OLED_RES;
//PB6 I2C1_SCL;
//PB7 I2C1_SDA;
/*I2C2*/
//PB10 I2C2_SCL;
//PB11 I2C2_SDA;

#if I2C1_SOFT
#define I2C1_SDA_LOW() GPIO_ResetBits(GPIOB,GPIO_Pin_7) //I2C1_SDA PB7
#define I2C1_SDA_HIGH() GPIO_SetBits(GPIOB,GPIO_Pin_7)
#define I2C1_SCL_LOW() GPIO_ResetBits(GPIOB,GPIO_Pin_6) //I2C1_SCL PB6
#define I2C1_SCL_HIGH() GPIO_SetBits(GPIOB,GPIO_Pin_6)

//#define I2C1_SDA_IN() {GPIOE->MODER &= 0xFFFF3FFF;\
//												GPIOE->PUPDR &= 0xFFFF3FFF;\
//												GPIOE->PUPDR |= 0x4000;}// ��յ�7pin������Ϊ����,����
//#define I2C1_SDA_OUT() {GPIOE->MODER &= 0xFFFF3FFF;\
//												GPIOE->MODER |= 0x4000;\
//												GPIOE->OSPEEDR &= 0xFFFF3FFF;\
//												GPIOE->OSPEEDR |= 0x4000;\
//												GPIOE->PUPDR &= 0xFFFF3FFF;\
//												GPIOE->PUPDR |= 0x4000;}
#define I2C1_SDA_OUT()	do{GPIOB->MODER&=~(3<<(7*2));GPIOB->MODER|=1<<7*2;}while(0)
#define I2C1_SDA_IN()	do{GPIOB->MODER&=~(3<<(7*2));GPIOB->MODER|=0<<7*2;}while(0)
#endif

#if I2C2_SOFT
#define I2C2_SDA_LOW() GPIO_ResetBits(GPIOB,GPIO_Pin_11) //I2C2_SDA PB11
#define I2C2_SDA_HIGH() GPIO_SetBits(GPIOB,GPIO_Pin_11)
#define I2C2_SCL_LOW() GPIO_ResetBits(GPIOB,GPIO_Pin_10) //I2C2_SCL PB10
#define I2C2_SCL_HIGH() GPIO_SetBits(GPIOB,GPIO_Pin_10)
#define I2C2_SDA_OUT()	{GPIOB->MODER&=~(3<<(11*2));GPIOB->MODER|=1<<11*2;}
#define I2C2_SDA_IN()	{GPIOB->MODER&=~(3<<(11*2));GPIOB->MODER|=0<<11*2;}


#define I2C2_READ_SDA PBin(11)
#endif

extern unsigned char I2C_Err1;
extern unsigned char I2C_Err2;
void I2C1_Config(void);
void I2C2_Config(void);

uint8_t I2C1_ReadOneByte(uint8_t I2C_Addr,uint8_t Reg_addr);
void I2C1_WriteOneByte(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t value);
uint8_t I2C1_ReadBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t * buffer);
uint8_t I2C1_WriteBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t * buffer);

uint8_t I2C2_ReadOneByte(uint8_t I2C_Addr,uint8_t Reg_addr);
void I2C2_WriteOneByte(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t value);
uint8_t I2C2_ReadBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t * buffer);
uint8_t I2C2_WriteBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t * buffer);



#endif
