#include "spi.h"
#include "delay.h"
#if SPI1_SOFT
void SPI_Soft_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);

	//PB5��MOSI
	//PB4��MISO
	//PB3: SCK
	//PB0��CS
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 |GPIO_Pin_3 |GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOB,&GPIO_InitStructure);	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_Init(GPIOB,&GPIO_InitStructure);	
	SPI1_ReadWriteByte(0xff);
}

#if SPI1_MODE == 0
uint8_t SPIReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	SPI1_SCK = 0;
	for(i=0;i<8;i++)
	{
		SPI1_SCK = 0;
		if(data&0x80) SPI1_MOSI = 1;
		else SPI1_MOSI = 0;
		SPI1_SCK = 1;
		data <<=1;
		tmp <<=1;
		if(SPI1_MISO) tmp |= 0x01;
	}
	SPI1_SCK = 0;
	return tmp;
}
#elif SPI1_MODE == 1
uint8_t SPIReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	SPI1_SCK = 0;
	for(i=0;i<8;i++)
	{
		SPI1_SCK = 1;
		if(data&0x80) SPI1_MOSI = 1;
		else SPI1_MOSI = 0;
		SPI1_SCK = 0;
		data <<=1;
		tmp <<=1;
		if(SPI1_MISO) tmp |= 0x01;
	}
	SPI1_SCK = 0;
	return tmp;
}
#elif SPI1_MODE == 2
uint8_t SPIReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	SPI1_SCK = 1;
	for(i=0;i<8;i++)
	{
		SPI1_SCK = 1;
		if(data&0x80) SPI1_MOSI = 1;
		else SPI1_MOSI = 0;
		SPI1_SCK = 0;
		data <<=1;
		tmp <<=1;
		if(SPI1_MISO) tmp |= 0x01;
	}
	SPI1_SCK = 1;
	return tmp;
}
#elif SPI1_MODE == 3
uint8_t SPIReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	SPI1_SCK = 1;
	for(i=0;i<8;i++)
	{
		SPI1_SCK = 0;
		if(data&0x80) SPI1_MOSI = 1;
		else SPI1_MOSI = 0;
		delay_us(1);
		SPI1_SCK = 1;
		data <<=1;
		tmp <<=1;
		if(SPI1_MISO) tmp |= 0x01;
		delay_us(1);
	}
	SPI1_SCK = 1;
	return tmp;
}
#endif
uint8_t SPI1_ReadWriteByte(uint8_t data) __attribute__((weak,alias("SPIReadWriteByte")));
void SPI1_Init(void) __attribute__((weak,alias("SPI_Soft_Init")));
#else
void SPI1_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	SPI_InitTypeDef SPI_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 |GPIO_Pin_4 |GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	GPIO_PinAFConfig(GPIOB,GPIO_PinSource3,GPIO_AF_SPI1);
	GPIO_PinAFConfig(GPIOB,GPIO_PinSource4,GPIO_AF_SPI1);
	GPIO_PinAFConfig(GPIOB,GPIO_PinSource5,GPIO_AF_SPI1);

	RCC_APB2PeriphResetCmd(RCC_APB2Periph_SPI1,ENABLE);	
	RCC_APB2PeriphResetCmd(RCC_APB2Periph_SPI1,DISABLE);
	
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;//SPI����Ϊ˫��˫��ȫ˫��
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;//����ģʽ
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;//֡��С
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;	//CPOL=1	
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;//CPHA=1	,spi mode 3
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;	//�����趨Ƭѡ����
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_2;//��� 84Mhz/2=42
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB; //MSB��ǰ
	SPI_InitStructure.SPI_CRCPolynomial = 2; //CRCֵ����Ķ���ʽ,����1
	SPI_Init(SPI1,&SPI_InitStructure);
	
	SPI_Cmd(SPI1,ENABLE);										//ʹ��spi1
	SPI1_ReadWriteByte(0xff);
}

//SPI1�ٶ����ú���
//SPI�ٶ�=fAPB2/��Ƶϵ��
//@ref SPI_BaudRate_Prescaler:SPI_BaudRatePrescaler_2~SPI_BaudRatePrescaler_256  
//APB2ʱ��һ��Ϊ84Mhz��
void SPI1_SetSpeed(uint8_t SPI_BaudRatePrescaler)
{
  assert_param(IS_SPI_BAUDRATE_PRESCALER(SPI_BaudRatePrescaler));
	SPI1->CR1&=0XFFC7;//λ3-5���㣬�������ò�����
	SPI1->CR1|=SPI_BaudRatePrescaler;	//����SPI1�ٶ� 
	SPI_Cmd(SPI1,ENABLE); //ʹ��SPI1
} 

//�շ�һ���ֽ�
uint8_t SPI1_ReadWriteByte(uint8_t data)
{
	uint8_t spi_time_out;
  while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET)
	{
		spi_time_out++;
		if (spi_time_out >200) return 0;		
	}//�ȴ���������  
	SPI_I2S_SendData(SPI1, data); //ͨ������SPIx����һ��byte  ����
	
	spi_time_out=0;	
  while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET)
	{
		spi_time_out++;
		if (spi_time_out >200) return 0;		
	} //�ȴ�������һ��byte  
	return SPI_I2S_ReceiveData(SPI1); //����ͨ��SPIx������յ�����	
}
#endif

void SPI2_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	SPI_InitTypeDef SPI_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	GPIO_PinAFConfig(GPIOB,GPIO_PinSource13,GPIO_AF_SPI2);
	GPIO_PinAFConfig(GPIOB,GPIO_PinSource14,GPIO_AF_SPI2);
	GPIO_PinAFConfig(GPIOB,GPIO_PinSource15,GPIO_AF_SPI2);

	RCC_APB1PeriphResetCmd(RCC_APB1Periph_SPI2,ENABLE);	
	RCC_APB1PeriphResetCmd(RCC_APB1Periph_SPI2,DISABLE);
	
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;//SPI����Ϊ˫��˫��ȫ˫��
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;//����ģʽ
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;//֡��С
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;	//CPOL=0	
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;//CPHA=1	,spi mode 1
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;	//�����趨Ƭѡ����
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_2;//���SPIʱ��Ϊ37.5Mbits/s 42Mhz/2=21
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB; //MSB��ǰ
	SPI_InitStructure.SPI_CRCPolynomial = 7; //CRCֵ����Ķ���ʽ,����1
	SPI_Init(SPI2,&SPI_InitStructure);
	
	SPI_Cmd(SPI2,ENABLE);										//ʹ��spi2
}

//DMA
void LCD_DMA1_Transfer(uint32_t data)
{
	DMA_InitTypeDef DMA_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1,ENABLE);
	
	while(DMA_GetCmdStatus(DMA1_Stream4)!=DISABLE);
	DMA_DeInit(DMA1_Stream4);
	DMA_InitStructure.DMA_Channel = DMA_Channel_0; 									//dac1 ��DMA1 stream4 channel 0
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&SPI2->DR;	//spi2���ݼĴ���
	DMA_InitStructure.DMA_Memory0BaseAddr = data;
	DMA_InitStructure.DMA_BufferSize = 1;											 	    //���δ��������ֽ�
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_PeripheralDataSize_Byte;
	DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;					//����������
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;										//��1��
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
	DMA_Init(DMA1_Stream4,&DMA_InitStructure);
	
	SPI_I2S_DMACmd(SPI2,SPI_I2S_DMAReq_Tx,ENABLE);
	DMA_Cmd(DMA1_Stream4,ENABLE);
}
//SPI2�ٶ����ú���
//SPI�ٶ�=fAPB1/��Ƶϵ��
//@ref SPI_BaudRate_Prescaler:SPI_BaudRatePrescaler_2~SPI_BaudRatePrescaler_256  
//APB2ʱ��һ��Ϊ42Mhz��
void SPI2_SetSpeed(uint8_t SPI_BaudRatePrescaler)
{
  assert_param(IS_SPI_BAUDRATE_PRESCALER(SPI_BaudRatePrescaler));
	SPI2->CR1&=0XFFC7;//λ3-5���㣬�������ò�����
	SPI2->CR1|=SPI_BaudRatePrescaler;	//����SPI1�ٶ� 
	SPI_Cmd(SPI2,ENABLE); //ʹ��SPI
} 

uint8_t SPI2_ReadWriteByte(uint8_t data)
{
	uint8_t spi_time_out;
  while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET)
	{
		spi_time_out++;
		if (spi_time_out >200) return 0;
	}//�ȴ���������  
	SPI_I2S_SendData(SPI2, data); //ͨ������SPIx����һ��byte  ����
	//LCD_DMA1_Transfer((uint32_t)&data);
	spi_time_out=0;	
  while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET)
	{
		spi_time_out++;
		if (spi_time_out >200) return 0;		
	} //�ȴ�������һ��byte  
	return SPI_I2S_ReceiveData(SPI2); //����ͨ��SPIx������յ�����	
}


void SPI3_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_11|GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOE,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_Init(GPIOE,&GPIO_InitStructure);
}

#if SPI3_MODE == 0
uint8_t SPI3_ReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	for(i=0;i<8;i++)
	{
		SPI3_SCK = 0;
		if(data&0x80) SPI3_MOSI = 1;
		else SPI3_MOSI = 0;
		data <<=1;
		SPI3_SCK = 1;
		tmp <<=1;
		if(SPI3_MISO) tmp |= 0x01;
	}
	SPI3_SCK = 0;
	return tmp;
}
#elif SPI3_MODE == 1
uint8_t SPI3_ReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	SPI3_SCK = 0;
	for(i=0;i<8;i++)
	{
		SPI3_SCK = 1;
		if(data&0x80) SPI3_MOSI = 1;
		else SPI3_MOSI = 0;
		SPI3_SCK = 0;
		data <<=1;
		tmp <<=1;
		if(SPI3_MISO) tmp |= 0x01;
	}
	SPI3_SCK = 0;
	return tmp;
}
#elif SPI3_MODE == 2
uint8_t SPI3_ReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	SPI3_SCK = 1;
	for(i=0;i<8;i++)
	{
		SPI3_SCK = 1;
		if(data&0x80) SPI3_MOSI = 1;
		else SPI3_MOSI = 0;
		SPI3_SCK = 0;
		data <<=1;
		tmp <<=1;
		if(SPI3_MISO) tmp |= 0x01;
	}
	SPI3_SCK = 1;
	return tmp;
}
#elif SPI3_MODE == 3
uint8_t SPI3_ReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	SPI3_SCK = 1;
	for(i=0;i<8;i++)
	{
		SPI3_SCK = 0;
		if(data&0x80) SPI3_MOSI = 1;
		else SPI3_MOSI = 0;
		delay_us(1);
		SPI3_SCK = 1;
		data <<=1;
		tmp <<=1;
		if(SPI3_MISO) tmp |= 0x01;
		delay_us(1);
	}
	SPI3_SCK = 1;
	return tmp;
}
#endif

void SPI4_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_5|GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOD,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_Init(GPIOD,&GPIO_InitStructure);
}

#if SPI4_MODE == 0
uint8_t SPI4_ReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	for(i=0;i<8;i++)
	{
		SPI4_SCK = 0;
		if(data&0x80) SPI4_MOSI = 1;
		else SPI4_MOSI = 0;
		SPI4_SCK = 1;
		data <<=1;
		tmp <<=1;
		if(SPI4_MISO) tmp |= 0x01;
	}
	SPI4_SCK = 0;
	return tmp;
}
#elif SPI4_MODE == 1
uint8_t SPI4_ReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	SPI4_SCK = 0;
	for(i=0;i<8;i++)
	{
		SPI4_SCK = 1;
		if(data&0x80) SPI4_MOSI = 1;
		else SPI4_MOSI = 0;
		SPI4_SCK = 0;
		data <<=1;
		tmp <<=1;
		if(SPI4_MISO) tmp |= 0x01;
	}
	SPI4_SCK = 0;
	return tmp;
}
#elif SPI4_MODE == 2
uint8_t SPI4_ReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	SPI4_SCK = 1;
	for(i=0;i<8;i++)
	{
		SPI4_SCK = 1;
		if(data&0x80) SPI4_MOSI = 1;
		else SPI4_MOSI = 0;
		SPI4_SCK = 0;
		data <<=1;
		tmp <<=1;
		if(SPI4_MISO) tmp |= 0x01;
	}
	SPI4_SCK = 1;
	return tmp;
}
#elif SPI4_MODE == 3
uint8_t SPI4_ReadWriteByte(uint8_t data)
{
	uint8_t i,tmp=0;
	SPI4_SCK = 1;
	for(i=0;i<8;i++)
	{
		SPI4_SCK = 0;
		if(data&0x80) SPI4_MOSI = 1;
		else SPI4_MOSI = 0;
		delay_us(1);
		SPI4_SCK = 1;
		data <<=1;
		tmp <<=1;
		if(SPI4_MISO) tmp |= 0x01;
		delay_us(1);
	}
	SPI4_SCK = 1;
	return tmp;
}
#endif