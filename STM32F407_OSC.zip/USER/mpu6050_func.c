#include "includes.h"

#define PI 3.14159265

void mpu6050_acc_raw(void)
{
	static float tmp_accx,tmp_accy,tmp_accz,tmp_gyrx,tmp_gyry,tmp_gyrz;
	static float tmp_angle_xz,tmp_angle_yz;
	static short accx_offset=0,accy_offset=0,accz_offset=0;															//���ٶȲ���ֵ
	static short gyrx_offset=0,gyry_offset=0,gyrz_offset=0;															//�����ǲ���ֵ
	
	if(osc.mpu6050_adjust == 1)																													//mpu6050У׼
	{
		mpu_dmp_init();
		osc.mpu6050_adjust = 0;
		for(uint8_t i = 0;i<10;i++)
		{
			MPU_Get_Accelerometer(&osc.mpu6050_accx,&osc.mpu6050_accy,&osc.mpu6050_accz);	
			MPU_Get_Gyroscope(&osc.mpu6050_gyrx,&osc.mpu6050_gyry,&osc.mpu6050_gyrz);	
			accx_offset+= osc.mpu6050_accx;
			accy_offset+= osc.mpu6050_accy;
			accz_offset+= osc.mpu6050_accz-16384;																	//Ĭ��оƬˮƽ���ã�z���ϴ�������g
			
			gyrx_offset+=osc.mpu6050_gyrx;
			gyry_offset+=osc.mpu6050_gyry;
			gyrz_offset+=osc.mpu6050_gyrz;
		}
		accx_offset=accx_offset/10;
		accy_offset=accy_offset/10;
		accz_offset=accz_offset/10;
		gyrx_offset=gyrx_offset/10;
		gyry_offset=gyry_offset/10;
		gyrz_offset=gyrz_offset/10;
	}
	
	MPU_Get_Accelerometer(&osc.mpu6050_accx,&osc.mpu6050_accy,&osc.mpu6050_accz);					//��ȡ���ٶ�ԭʼֵ,16λad,��2g��Χ,������:2^16/4=16384 LSB/g
	MPU_Get_Gyroscope(&osc.mpu6050_gyrx,&osc.mpu6050_gyry,&osc.mpu6050_gyrz);						//��ȡ������ԭʼֵ,16λad,��2000deg/s,������:2^16/4000=16.4 LSB/(��/s)
	tmp_accx = osc.mpu6050_accx-accx_offset;
	tmp_accy = osc.mpu6050_accy-accy_offset;
	tmp_accz = osc.mpu6050_accz-accz_offset;
	tmp_gyrx = osc.mpu6050_gyrx-gyrx_offset;
	tmp_gyry = osc.mpu6050_gyry-gyry_offset;
	tmp_gyrz = osc.mpu6050_gyrz-gyrz_offset;

	/*��ʾ���ٶ�ԭʼֵ*/
	if(tmp_accx >= 0)	OLED_NUM(50,10,tmp_accx,5,font_6x8,1);
	else 
	{
		OLED_Char(50,10,'-',font_6x8,1);
		OLED_NUM(56,10,0-tmp_accx,5,font_6x8,1);
	}
	if(tmp_accy >= 0)	OLED_NUM(50,11,tmp_accy,5,font_6x8,1);
	else
	{
		OLED_Char(50,11,'-',font_6x8,1);
		OLED_NUM(56,11,0-tmp_accy,5,font_6x8,1);		
	}
	if(tmp_accz >= 0)	OLED_NUM(50,12,tmp_accz,5,font_6x8,1);
	else
	{
		OLED_Char(50,12,'-',font_6x8,1);
		OLED_NUM(56,12,0-tmp_accz,5,font_6x8,1);		
	}

	/*��ʾ������ԭʼֵ*/
	if(tmp_gyrx >= 0)	OLED_NUM(50,13,tmp_gyrx,5,font_6x8,1);
	else 
	{
		OLED_Char(50,13,'-',font_6x8,1);
		OLED_NUM(56,13,0-tmp_gyrx,5,font_6x8,1);
	}
	if(tmp_gyry >= 0)	OLED_NUM(50,14,tmp_gyry,5,font_6x8,1);
	else
	{
		OLED_Char(50,14,'-',font_6x8,1);
		OLED_NUM(56,14,0-tmp_gyry,5,font_6x8,1);		
	}
	if(tmp_gyrz >= 0)	OLED_NUM(50,15,tmp_gyrz,5,font_6x8,1);
	else
	{
		OLED_Char(50,15,'-',font_6x8,1);
		OLED_NUM(56,15,0-tmp_gyrz,5,font_6x8,1);		
	}
	//���ٶ����ݴ���
	//����roll��
	tmp_angle_xz = (atan(tmp_accy/tmp_accz))*180.0/PI;
	if(tmp_accz<0 && tmp_accy>0) tmp_angle_xz = 180+tmp_angle_xz;
	else if(tmp_accz<0 && tmp_accy<0) tmp_angle_xz = tmp_angle_xz-180;
	
	//����pitch
	tmp_angle_yz = -(atan(tmp_accx/tmp_accz))*180.0/PI;
	if(tmp_accz<0 && tmp_accx>0) tmp_angle_yz = tmp_angle_yz-180;
	else if(tmp_accz<0 && tmp_accx<0) tmp_angle_yz = 180+tmp_angle_yz;
	
	
	
	//���������ݴ���
	tmp_gyrx=tmp_gyrx/16.4;
	tmp_gyry=tmp_gyry/16.4;
	tmp_gyrz=tmp_gyrz/16.4;
	

	//��ʾroll��pitch�Ƕ�
	if(tmp_angle_xz >= 0)OLED_NUM(0,11,tmp_angle_xz,5,font_6x8,1);
	else 
	{
	OLED_Char(0,11,'-',font_6x8,1);
	OLED_NUM(6,11,0-tmp_angle_xz,5,font_6x8,1);
	}
	if(tmp_angle_yz >= 0)OLED_NUM(0,12,tmp_angle_yz,5,font_6x8,1);
	else 
	{
		OLED_Char(0,12,'-',font_6x8,1);
		OLED_NUM(6,12,0-tmp_angle_yz,5,font_6x8,1);
	}
	//��ʾ������
	if(tmp_gyrx >= 0)OLED_NUM(0,13,tmp_gyrx,5,font_6x8,1);
	else 
	{
	OLED_Char(0,13,'-',font_6x8,1);
	OLED_NUM(6,13,0-tmp_gyrx,5,font_6x8,1);
	}
	if(tmp_gyry >= 0)OLED_NUM(0,14,tmp_gyry,5,font_6x8,1);
	else 
	{
		OLED_Char(0,14,'-',font_6x8,1);
		OLED_NUM(6,14,0-tmp_gyry,5,font_6x8,1);
	}	
	if(tmp_gyrz >= 0)OLED_NUM(0,15,tmp_gyrz,5,font_6x8,1);
	else 
	{
		OLED_Char(0,15,'-',font_6x8,1);
		OLED_NUM(6,15,0-tmp_gyrz,5,font_6x8,1);
	}	
}







void mpu6050_refsresh(void)
{
	uint16_t time_out;
	static short tmp_pitch,tmp_roll,tmp_yaw;
	static uint8_t circle_x=63,circle_y=63;
	char dx=0,dy=0;
	while(mpu_dmp_get_data(&osc.mpu6050_pitch,&osc.mpu6050_roll,&osc.mpu6050_yaw)!=0){time_out++;if(time_out>60000) break;}
	mpu6050_acc_raw();
	if(osc.mpu6050_dev == 0)																																								//mpu6050������ʾ
	{
		OLED_NUM(102,15,osc.mpu6050_temp/10,2,font_6x8,1);																										//��ʾ�¶�
		OLED_NUM(120,15,osc.mpu6050_temp%10,1,font_6x8,1);		
		OLED_Char(114,15,'.',font_6x8,1);
																																							
		if(osc.mpu6050_pitch>=0)OLED_NUM(0,13,osc.mpu6050_pitch,5,font_6x8,1);																//��ʾŷ����
		else
		{
			OLED_Char(0,13,'-',font_6x8,1);
			OLED_NUM(6,13,0-osc.mpu6050_pitch,5,font_6x8,1);
		}
		if(osc.mpu6050_roll>=0)OLED_NUM(0,14,osc.mpu6050_roll,5,font_6x8,1);
		else
		{
			OLED_Char(0,14,'-',font_6x8,1);
			OLED_NUM(6,14,0-osc.mpu6050_roll,5,font_6x8,1);
		}
		if(osc.mpu6050_yaw>=0)OLED_NUM(0,15,osc.mpu6050_yaw,5,font_6x8,1);
		else
		{
			OLED_Char(0,15,'-',font_6x8,1);
			OLED_NUM(6,15,0-osc.mpu6050_yaw,5,font_6x8,1);
		}			
		
	}else OLED_String(111,14,"NG",font_6x8,1);		
	
	//OLED_DrawLine(63,63,63*(1+cos(PI*osc.mpu6050_yaw/180)),63*(1+sin(PI*osc.mpu6050_yaw/180)));
	
	if((short)osc.mpu6050_pitch > tmp_pitch) 
	{
		dy = -1;
	}
	else if((short)osc.mpu6050_pitch < tmp_pitch)
	{
		dy = 1;
	}
	else if((short)osc.mpu6050_pitch == tmp_pitch) dy = 0;
	
	if((short)osc.mpu6050_roll > tmp_roll) 
	{
		dx = 1;
	}
	else if((short)osc.mpu6050_roll < tmp_roll)
	{
		dx = -1;
	}
	else if((short)osc.mpu6050_roll == tmp_roll) dx = 0;	
	

	circle_x=circle_x+(circle_x == 0?(dx>0?dx:0):dx);
	circle_y=circle_y+(circle_y == 0?(dy>0?dy:0):dy);
	
	if(circle_y >= 127)
	{
		circle_y = 127;
	}
	if(circle_x >= 127)
	{
		circle_x = 127;
	}
	
	// OLED_DrawCircleFill(circle_x,circle_y,2);
	// OLED_DrawCircle(circle_x,circle_y,6);
	
	OLED_NUM(85,14,circle_x,3,font_6x8,1);																								
	OLED_NUM(109,14,circle_y,3,font_6x8,1);	
	OLED_Char(103,14,',',font_6x8,1);
	tmp_pitch = (short)osc.mpu6050_pitch;
	tmp_roll = (short)osc.mpu6050_roll;
	tmp_yaw = (short)osc.mpu6050_yaw;
}


