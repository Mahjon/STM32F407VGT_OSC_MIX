#include "includes.h"

extern uint16_t m;
void user_task1(void)
{
	static unsigned char flag=1;
	
	if(flag)
	{
		m+=1;
		if(m>128) flag=0;
	}
	else 
	{
		m-=1;
		if(m<1) flag=1;
	} 
	if(osc.bmp280_dev->bmp280_id == 0x58)
	{
		osc.bmp280_dev->bmp280_temp = BMP280_Get_Temp();
		osc.bmp280_dev->bmp280_pressure = BMP280_Get_Press();
		osc.bmp280_dev->bmp280_elevation = ((101325-osc.bmp280_dev->bmp280_pressure)/100)*9;		
	}
	
	//IWDG_ReloadCounter();//ι��
	//Set_pwm4(TIM2,m);
	//TIM_SetCompare4(TIM2,m);
}

void user_task2(void)
{
	LED2=!LED2;	
}