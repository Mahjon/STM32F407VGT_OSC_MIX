#ifndef _icon_H
#define _icon_H
#include "stdint.h"
extern const uint8_t F6x8[][6];
extern const uint8_t F8x16[][8];
extern const uint8_t image_select1[][8];
extern const uint8_t image_select2[][8];
extern const uint8_t menu_accuracy_icon[][24];
extern const uint8_t menu_clock_icon[][24];
extern const uint8_t menu_cursor_icon[][24];
extern const uint8_t menu_flash_icon[][24];
extern const uint8_t menu_halt_icon[][24];
extern const uint8_t menu_NRF24L01_icon[][24];
extern const uint8_t menu_wave_icon[][24];
extern const uint8_t menu_zoom_icon[][24];
extern const uint8_t menu_position_icon[][24];
#endif
