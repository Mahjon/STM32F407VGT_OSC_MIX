#include "usart.h"
#include "stm32f4xx_rcc.h"
void USART_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE); //UART1��UART6
	//RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE); //UART2~5
	RCC_APB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);

	GPIO_PinAFConfig(GPIOA,GPIO_Pin_9|GPIO_Pin_10,GPIO_AF_USART1);
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;          //����ģʽ
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;        //�������
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9|GPIO_Pin_10; //Pin9��10
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;          //����
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate=;
	USART_InitStructure.USART_HardwareFlowControl=;
	USART_InitStructure.USART_Mode=;
	USART_InitStructure.USART_Parity=;
	USART_InitStructure.USART_StopBits=;
	USART_InitStructure.USART_WordLength=;//
	USART_Init();
}