#ifndef _WKUP_H
#define	_WKUP_H
#include "sys.h"
#define WK_UP	PAin(0)
void WKUP_Init(void);
void Sys_Enter_Standby(void);
#endif
