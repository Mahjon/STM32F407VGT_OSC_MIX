#ifndef _DAC_H
#define _DAC_H
#include "sys.h"
#define WAVE_DOT 128
#define DAC_VOLTAGE 3120
extern uint16_t DAC_Data[WAVE_DOT];
typedef enum
{
	WAVE_SIN = 0,
	WAVE_TRIANGLE,
	WAVE_SAWTOOTH,
	WAVE_SQUARE,
	WAVE_CIRCLE,
	WAVE_NOISE,
	WAVE_MAX
}WAVE_MODE;
void Dac1_Init(void);		//DACͨ��1��ʼ��	 	 
void Dac1_Set_Vol(u16 vol);	//����ͨ��1�����ѹ
void Wave_Generator(WAVE_MODE mode,uint16_t voltage_max,uint16_t *wave_data);
#endif
