#ifndef _timer_H
#define _timer_H
#include "sys.h"

typedef void (*callback)(void);
void TIME3_Initi(void);
void TIME4_Initi(uint16_t arr,uint16_t psc);
void Timer_Initi(void);
void Timer_Config(unsigned char num,callback p,unsigned char mode,unsigned int period);
void Timer_Update(void);
#endif
