#include "hardiic.h"
#include "delay.h"

uint32_t ulTimeOut_Time; //��ʱ����
unsigned char I2C_Err1=0;
unsigned char I2C_Err2=0;

#if I2C1_SOFT

//PB9 OLED_EN;
//PB8 OLED_RES;
//PB6 I2C1_SCL;
//PB7 I2C1_SDA;
void I2C1_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_6|GPIO_Pin_7;

	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	I2C1_SDA_HIGH();
	I2C1_SCL_HIGH();
}

void I2C1_SATRT(void)
{
	//OLED_SCL_LOW();
	//delay_us(1);
	I2C1_SDA_OUT();
	I2C1_SDA_HIGH();
	I2C1_SCL_HIGH();
	//delay_us(4);
	I2C1_SDA_LOW();
	//delay_us(4);
	I2C1_SCL_LOW();
}
void I2C1_STOP(void)
{
	I2C1_SDA_OUT();
	I2C1_SCL_LOW();
	I2C1_SDA_LOW();
	//delay_us(3);
	I2C1_SCL_HIGH();
	//delay_us(1);
	I2C1_SDA_HIGH();
	//delay_us(4);
}

//�ȴ�Ӧ��
uint8_t I2C1_WAIT_ACK(void) //return 0:ACK 1��NO ACK
{
	uint8_t err_count;
	I2C1_SDA_IN();//��SDA����Ϊ���룬�ȴ��͵�ƽ(ACK)
	I2C1_SDA_HIGH();
	//delay_us(1);
	I2C1_SCL_HIGH();
	//delay_us(1);
	while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7)) 
	{
		err_count++;
		if(err_count>250)
		{
			I2C1_STOP();
			return 1;
		}
	}
	I2C1_SCL_LOW();
	return 0;
}
//д�ֽ�
void I2C1_WriteByte(uint8_t data)
{
	uint8_t i;
	I2C1_SDA_OUT();
	I2C1_SCL_LOW();
	for(i=0;i<8;i++)
	{
		if((data&0x80)>>7)
		{
			I2C1_SDA_HIGH();
		}
		else
		{
			I2C1_SDA_LOW();
		}
		data<<=1;
		I2C1_SCL_HIGH();
		delay_us(1);   //����ʡ�ԣ�����
		I2C1_SCL_LOW();
		//delay_us(2);
	}
}

//д1���ֽ�
void I2C1_WriteOneByte(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t value)
{
	I2C1_SATRT();
	I2C1_WriteByte((I2C_Addr<<1)|0);
	I2C1_WAIT_ACK();

	I2C1_WriteByte(Reg_addr);//д����
	I2C1_WAIT_ACK();
	I2C1_WriteByte(value);
	I2C1_WAIT_ACK();
	I2C1_STOP();
}
//��1���ֽ� ������Ӧ��
uint8_t I2C1_ReadOneByte(uint8_t I2C_Addr,uint8_t Reg_addr)
{
	uint8_t i,data;
	
	I2C1_SATRT();
	I2C1_WriteByte((I2C_Addr<<1)|0);
	I2C1_WAIT_ACK();
	I2C1_WriteByte(Reg_addr);
	I2C1_WAIT_ACK();
	I2C1_SATRT();
	I2C1_WriteByte((I2C_Addr<<1)|1);
	I2C1_WAIT_ACK();
	I2C1_SDA_IN();
	for(i=0;i<8;i++)
	{
		I2C1_SCL_LOW();
		//delay_us(1);
		I2C1_SCL_HIGH();
		data<<=1;
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7))data++;
		delay_us(1);
	}
	I2C1_SCL_LOW();
	I2C1_SDA_OUT();
	I2C1_SDA_HIGH();
	I2C1_SCL_HIGH();
	//delay_us(1);
	I2C1_SCL_LOW();
	I2C1_STOP();
	return data;
}

//����дlen�ֽ�
uint8_t I2C1_WriteBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t * buffer)
{
	uint8_t i,Err;
	I2C1_SATRT();
	I2C1_WriteByte((I2C_Addr<<1)|0);
	Err = I2C1_WAIT_ACK();
	I2C1_WriteByte(Reg_addr);
	I2C1_WAIT_ACK();
	for(i=0;i<len;i++)
	{
		I2C1_WriteByte(buffer[i]);
		Err = I2C1_WAIT_ACK();
	}
	I2C1_STOP();
	return Err;
}

//������len�ֽ�
uint8_t I2C1_ReadBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t * buffer)
{
	uint8_t i,j,tmp,Err;
	
	I2C1_SATRT();
	I2C1_WriteByte((I2C_Addr<<1)|0);
	Err = I2C1_WAIT_ACK();
	I2C1_WriteByte(Reg_addr);
	I2C1_WAIT_ACK();
	I2C1_SATRT();
	I2C1_WriteByte((I2C_Addr<<1)|1);
	I2C1_WAIT_ACK();
	while(len)
	{
		I2C1_SDA_IN();
		tmp=0;
		for(j=0;j<8;j++)
		{
			I2C1_SCL_LOW();
			delay_us(1);							//����ʡ��
			I2C1_SCL_HIGH();
			tmp<<=1;
			if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7))tmp++;
		}
		if(len == 1)
		{	
			I2C1_SCL_LOW();
			I2C1_SDA_OUT();
			I2C1_SDA_HIGH();
			I2C1_SCL_HIGH();
			I2C1_SCL_LOW();		
		}
		else
		{
			I2C1_SCL_LOW();
			I2C1_SDA_OUT();
			I2C1_SDA_LOW();
			I2C1_SCL_HIGH();
			I2C1_SCL_LOW();					
		}
		*buffer = tmp ;
		len--;
		buffer++;
	}
	I2C1_STOP();
	return Err;
}
#else
void I2C1_Config(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    I2C_InitTypeDef I2C_InitStructure;
    RCC_ClocksTypeDef   rcc_clocks;
	

    /* GPIO Peripheral clock enable */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
      /* Reset I2Cx IP */
    RCC_APB1PeriphResetCmd(RCC_APB1Periph_I2C1, ENABLE);
    /* Release reset signal of I2Cx IP */
    RCC_APB1PeriphResetCmd(RCC_APB1Periph_I2C1, DISABLE);

    /*I2C1 configuration*/
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_I2C1); //ע�⣬�˴����ܺϲ�д��
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_I2C1);

    //PB6: I2C1_SCL  PB7: I2C1_SDA
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /* I2C Struct Initialize */
    I2C_DeInit(I2C1);
    I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
    I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
    I2C_InitStructure.I2C_OwnAddress1 = 0x00;
    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
    I2C_InitStructure.I2C_ClockSpeed = 700000;  //max:875000
    I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
    I2C_Init(I2C1, &I2C_InitStructure);

    /* I2C Initialize */
    I2C_Cmd(I2C1, ENABLE);

		/*�������ų�ʼ��*/
		GPIO_InitTypeDef OLED;
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
		OLED.GPIO_Mode=GPIO_Mode_OUT;
		OLED.GPIO_OType=GPIO_OType_PP;
		OLED.GPIO_Pin=GPIO_Pin_8|GPIO_Pin_9;
		//PB9 OLED_EN;
		//PB8 OLED_RES;
		OLED.GPIO_PuPd=GPIO_PuPd_UP;
		OLED.GPIO_Speed=GPIO_Speed_50MHz;
		GPIO_Init(GPIOB,&OLED);
		
    /*��ʱ����*/
    RCC_GetClocksFreq(&rcc_clocks);
    ulTimeOut_Time = (rcc_clocks.SYSCLK_Frequency /10000); 
}

//������len�ֽ�(С��256)
uint8_t I2C1_ReadBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t *buffer)
{
    uint8_t readout;
    uint32_t tmr;

    tmr = ulTimeOut_Time;
    while((--tmr)&&I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY));						//�ȴ�׼������
    if(tmr==0)	I2C_Err1 = 1;

    I2C_GenerateSTART(I2C1, ENABLE);																	//����I2C��START�źţ��ӿ��Զ��Ӵ��豸������豸
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT)));
		if(tmr==0)	I2C_Err1 = 1;
	
		I2C_Send7bitAddress(I2C1,(I2C_Addr<<1)|0,I2C_Direction_Transmitter);//����д����
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)));
    if(tmr==0)	I2C_Err1 = 1;

		I2C_SendData(I2C1, Reg_addr);																				//��������
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
    if(tmr==0)	I2C_Err1 = 1;
		
    I2C_GenerateSTART(I2C1, ENABLE);																	//����start�ź�
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT)));
    if(tmr==0)	I2C_Err1 = 1;
		
    I2C_Send7bitAddress(I2C1,(I2C_Addr<<1)|1, I2C_Direction_Receiver);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED)));
    if(tmr==0)	I2C_Err1 = 1;

		while(len)
		{
			tmr = ulTimeOut_Time;		
			while((--tmr)&&(!(I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED))));  /* EV7 */
			if(tmr==0)	I2C_Err1 = 1;
			
			*buffer = I2C_ReceiveData(I2C1);
			len--;
			buffer++;				
			if(len == 1)																										//�������һ�����ݾͲ�����Ӧ���ź��˲��ر�IIC
			{
				I2C_AcknowledgeConfig(I2C1, DISABLE);								
			}
		}
		I2C_GenerateSTOP(I2C1, ENABLE);			
    I2C_AcknowledgeConfig(I2C1, ENABLE);															//���¿���ACK
		return I2C_Err1;
}

//����дlen�ֽ�(С��256)
uint8_t I2C1_WriteBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t *buffer)
{
    uint32_t tmr;

    tmr = ulTimeOut_Time;
//    while(I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY));
    while((--tmr)&&I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY));
    if(tmr==0)	I2C_Err1 = 1; 

    I2C_GenerateSTART(I2C1, ENABLE);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT))); 
    if(tmr==0)	I2C_Err1 = 1;
		
    I2C_Send7bitAddress(I2C1,(I2C_Addr<<1)|0, I2C_Direction_Transmitter);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)));
    if(tmr==0)	I2C_Err1 = 1; 

    I2C_SendData(I2C1, Reg_addr);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
    if(tmr==0)	I2C_Err1 = 1;
		
		while(len)
		{
			I2C_SendData(I2C1, *buffer);
			buffer++;
			len--;
			tmr = ulTimeOut_Time;
			while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
			if(tmr==0)	I2C_Err1 = 1;
		}
		I2C_GenerateSTOP(I2C1, ENABLE);
		return I2C_Err1;
}

//��һ���ֽ�
uint8_t I2C1_ReadOneByte(uint8_t I2C_Addr,uint8_t Reg_addr)
{  
    uint8_t readout;
    uint32_t tmr;
	
    tmr = ulTimeOut_Time;
    while((--tmr)&&I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY));
    if(tmr==0)	I2C_Err1 = 1;
	
    I2C_GenerateSTART(I2C1, ENABLE);
    //����I2C��START�źţ��ӿ��Զ��Ӵ��豸������豸
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT)));
    if(tmr==0)	I2C_Err1 = 1;
	
    I2C_Send7bitAddress(I2C1,(I2C_Addr<<1)|0,I2C_Direction_Transmitter);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)));
    if(tmr==0)	I2C_Err1 = 1;

    I2C_SendData(I2C1, Reg_addr);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
    if(tmr==0)	I2C_Err1 = 1;
		
    I2C_GenerateSTART(I2C1, ENABLE);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT)));
    if(tmr==0)	I2C_Err1 = 1;

    I2C_Send7bitAddress(I2C1,(I2C_Addr<<1)|1, I2C_Direction_Receiver);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED)));
    if(tmr==0)	I2C_Err1 = 1;

    I2C_AcknowledgeConfig(I2C1, DISABLE);
    I2C_GenerateSTOP(I2C1, ENABLE);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!(I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED))));  /* EV7 */
    if(tmr==0)	I2C_Err1 = 1;

    readout = I2C_ReceiveData(I2C1);
    I2C_AcknowledgeConfig(I2C1, ENABLE);

    return readout;
}

//дһ���ֽ�
void I2C1_WriteOneByte(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t value)
{
    uint32_t tmr;

    tmr = ulTimeOut_Time;
    while((--tmr)&&I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY));
    if(tmr==0)	I2C_Err1 = 1;

    I2C_GenerateSTART(I2C1, ENABLE);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT))); 
    if(tmr==0)	I2C_Err1 = 1;

    I2C_Send7bitAddress(I2C1,(I2C_Addr<<1)|0, I2C_Direction_Transmitter);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)));
    if(tmr==0)	I2C_Err1 = 1;

    I2C_SendData(I2C1, Reg_addr);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
    if(tmr==0)	I2C_Err1 = 1;

    I2C_SendData(I2C1, value);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
		if(tmr==0)	I2C_Err1 = 1;

    I2C_GenerateSTOP(I2C1, ENABLE);
    //I2C_AcknowledgeConfig(I2Cx, DISABLE);
}
#endif

#if I2C2_SOFT 
//PB10 I2C2_SCL;
//PB11 I2C2_SDA;
void I2C2_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_10|GPIO_Pin_11;

	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	I2C2_SDA_HIGH();
	I2C2_SCL_HIGH();
}

void I2C2_SATRT(void)
{
	//OLED_SCL_LOW();
	//delay_us(1);
	I2C2_SDA_OUT();
	I2C2_SDA_HIGH();
	I2C2_SCL_HIGH();
	delay_us(1);
	I2C2_SDA_LOW();
	delay_us(1);
	I2C2_SCL_LOW();
	
}
void I2C2_STOP(void)
{
	I2C2_SDA_OUT();
	I2C2_SCL_LOW();
	I2C2_SDA_LOW();
	delay_us(1);
	I2C2_SCL_HIGH();
	delay_us(1);
	I2C2_SDA_HIGH();
}

//�ȴ�Ӧ��
//����0:����Ӧ��ɹ�
//����1:����Ӧ��ʧ��
uint8_t I2C2_WAIT_ACK(void) //return 0:ACK 1��NO ACK
{
	uint8_t err_count;
	I2C2_SDA_IN();//��SDA����Ϊ���룬�ȴ��͵�ƽ(ACK)		
	I2C2_SCL_HIGH();
	delay_us(1);
	while(I2C2_READ_SDA) 
	{
		err_count++;
		if(err_count>250)
		{
			I2C2_STOP();
			return 1;
		}
	}
	I2C2_SCL_LOW();
	I2C2_SDA_HIGH();
	return 0;
}
//д�ֽ�
void I2C2_WriteByte(uint8_t data)
{
	uint8_t i;
	I2C2_SDA_OUT();
	I2C2_SCL_LOW();
	delay_us(1);
	for(i=0;i<8;i++)
	{
		if((data&0x80)>>7)
		{
			I2C2_SDA_HIGH();
		}
		else
		{
			I2C2_SDA_LOW();
		}
		data<<=1;
//		delay_us(2); 
		I2C2_SCL_HIGH();
		delay_us(1);   //����ʡ�ԣ�����
		I2C2_SCL_LOW();
		delay_us(1); 
	}
}

//д1���ֽ�
void I2C2_WriteOneByte(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t value)
{
	I2C2_SATRT();
	I2C2_WriteByte((I2C_Addr<<1)|0);
	I2C2_WAIT_ACK();

	I2C2_WriteByte(Reg_addr);//д����
	I2C2_WAIT_ACK();
	I2C2_WriteByte(value);
	I2C2_WAIT_ACK();
	I2C2_STOP();
}
//��1���ֽ� ������Ӧ��
uint8_t I2C2_ReadOneByte(uint8_t I2C_Addr,uint8_t Reg_addr)
{
	uint8_t i,data;
	
	I2C2_SATRT();
	I2C2_WriteByte((I2C_Addr<<1)|0);
	I2C2_WAIT_ACK();
	I2C2_WriteByte(Reg_addr);
	I2C2_WAIT_ACK();
	delay_us(1);
	I2C2_SATRT();
	I2C2_WriteByte((I2C_Addr<<1)|1);
	I2C2_WAIT_ACK();
//	I2C2_SDA_IN();
	for(i=0;i<8;i++)
	{
		I2C2_SCL_LOW();
		delay_us(1);
		I2C2_SCL_HIGH();
		data<<=1;
		if(I2C2_READ_SDA)data++;
		delay_us(1);
	}
	I2C2_SCL_LOW();
	I2C2_SDA_OUT();
	I2C2_SDA_HIGH();
	delay_us(1);
	I2C2_SCL_HIGH();
	delay_us(1);
	I2C2_SCL_LOW();
	I2C2_STOP();
	return data;
}

//����дlen�ֽ�
uint8_t I2C2_WriteBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t * buffer)
{
	uint8_t i,Err;
	I2C2_SATRT();
	I2C2_WriteByte((I2C_Addr<<1)|0);
	Err = I2C2_WAIT_ACK();
	I2C2_WriteByte(Reg_addr);
	I2C2_WAIT_ACK();
	for(i=0;i<len;i++)
	{
		I2C2_WriteByte(buffer[i]);
		Err = I2C2_WAIT_ACK();
	}
	I2C2_STOP();
	return Err;
}

//������len�ֽ�
uint8_t I2C2_ReadBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t * buffer)
{
	uint8_t i,j,tmp,Err;
	
	I2C2_SATRT();
	I2C2_WriteByte((I2C_Addr<<1)|0);
	Err = I2C2_WAIT_ACK();
	I2C2_WriteByte(Reg_addr);
	I2C2_WAIT_ACK();
	I2C2_SATRT();
	I2C2_WriteByte((I2C_Addr<<1)|1);
	I2C2_WAIT_ACK();	
	while(len)
	{
		I2C2_SDA_IN();
		tmp=0;
		for(j=0;j<8;j++)
		{
			I2C2_SCL_LOW();
			delay_us(1);				//����ʡ��
			I2C2_SCL_HIGH();
			tmp<<=1;
			if(I2C2_READ_SDA)tmp++;
//			delay_us(1);
		}
		if(len == 1)
		{	
			I2C2_SCL_LOW();
			I2C2_SDA_OUT();
			I2C2_SDA_HIGH();
//			delay_us(2);
			I2C2_SCL_HIGH();
//			delay_us(2);
			I2C2_SCL_LOW();		
		}
		else
		{
			I2C2_SCL_LOW();
			I2C2_SDA_OUT();
			I2C2_SDA_LOW();
//			delay_us(2);
			I2C2_SCL_HIGH();
//			delay_us(1);
			I2C2_SCL_LOW();					
		}
		*buffer = tmp ;
		len--;
		buffer++;
	}
	I2C2_STOP();
	return Err;
}
#else
void I2C2_Config(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    I2C_InitTypeDef I2C_InitStructure;
    RCC_ClocksTypeDef   rcc_clocks;
	

    /* GPIO Peripheral clock enable */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C2, ENABLE);
      /* Reset I2Cx IP */
    RCC_APB1PeriphResetCmd(RCC_APB1Periph_I2C2, ENABLE);
    /* Release reset signal of I2Cx IP */
    RCC_APB1PeriphResetCmd(RCC_APB1Periph_I2C2, DISABLE);

    /*I2C1 configuration*/
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_I2C2); //ע�⣬�˴����ܺϲ�д��
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_I2C2);

    //PB10: I2C2_SCL  PB11: I2C2_SDA
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10|GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /* I2C Struct Initialize */
    I2C_DeInit(I2C2);
    I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
    I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
    I2C_InitStructure.I2C_OwnAddress1 = 0x00;
    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
    I2C_InitStructure.I2C_ClockSpeed = 100000;  //max:875000
    I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
    I2C_Init(I2C2, &I2C_InitStructure);

    /* I2C Initialize */
    I2C_Cmd(I2C2, ENABLE);	
    /*��ʱ����*/
    RCC_GetClocksFreq(&rcc_clocks);
    ulTimeOut_Time = (rcc_clocks.SYSCLK_Frequency /1000000); 
}


//������len�ֽ�(С��256)
uint8_t I2C2_ReadBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t * buffer)
{
    uint8_t readout;
    uint32_t tmr;

    tmr = ulTimeOut_Time;
    while((--tmr)&&I2C_GetFlagStatus(I2C2, I2C_FLAG_BUSY));						//�ȴ�׼������
    if(tmr==0) I2C_Err2 = 1;

    I2C_GenerateSTART(I2C2, ENABLE);																	//����I2C��START�źţ��ӿ��Զ��Ӵ��豸������豸
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)));
    if(tmr==0)	I2C_Err2 = 1;
		
		I2C_Send7bitAddress(I2C2,(I2C_Addr<<1)|0,I2C_Direction_Transmitter);//����д����
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2,I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)));
    if(tmr==0) I2C_Err2 = 1;

		I2C_SendData(I2C2, Reg_addr);																				//��������
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2,I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
    if(tmr==0)I2C_Err2 = 1;
		
    I2C_GenerateSTART(I2C2, ENABLE);																	//����start�ź�
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)));
    if(tmr==0) I2C_Err2 = 1;
		
    I2C_Send7bitAddress(I2C2,(I2C_Addr<<1)|1, I2C_Direction_Receiver);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED)));
    if(tmr==0) I2C_Err2 = 1;
		while(len)
		{
			tmr = ulTimeOut_Time;		
			while((--tmr)&&(!(I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED))));  /* EV7 */
			if(tmr==0)	I2C_Err2 = 1;	
			*buffer = I2C_ReceiveData(I2C2);
			
			len--;
			buffer++;				
			if(len == 1)																										//�������һ�����ݾͲ�����Ӧ���ź��˲��ر�IIC
			{
				I2C_AcknowledgeConfig(I2C2, DISABLE);								
			}
		}
		I2C_GenerateSTOP(I2C2, ENABLE);			
    I2C_AcknowledgeConfig(I2C2, ENABLE);															//���¿���ACK
		return I2C_Err2;
}

//����дlen�ֽ�(С��256)
uint8_t I2C2_WriteBytes(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t len,uint8_t * buffer)
{
    uint32_t tmr;

    tmr = ulTimeOut_Time;
//    while(I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY));
    while((--tmr)&&I2C_GetFlagStatus(I2C2, I2C_FLAG_BUSY));
    if(tmr==0) I2C_Err2 = 1;

    I2C_GenerateSTART(I2C2, ENABLE);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT))); 
    if(tmr==0)	I2C_Err2 = 1;
		
    I2C_Send7bitAddress(I2C2,(I2C_Addr<<1)|0, I2C_Direction_Transmitter);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)));
    if(tmr==0) I2C_Err2 = 1;

    I2C_SendData(I2C2, Reg_addr);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
    if(tmr==0)	I2C_Err2 = 1;
		
		while(len)
		{
			I2C_SendData(I2C2, *buffer);
			buffer++;
			len--;
			tmr = ulTimeOut_Time;
			while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
			if(tmr==0)	I2C_Err2 = 1;
		}
		I2C_GenerateSTOP(I2C2, ENABLE);
		return I2C_Err2;
}

//��һ���ֽ�
uint8_t I2C2_ReadOneByte(uint8_t I2C_Addr,uint8_t Reg_addr)
{  
    uint8_t readout;
    uint32_t tmr;
	
    tmr = ulTimeOut_Time;
    while((--tmr)&&I2C_GetFlagStatus(I2C2, I2C_FLAG_BUSY));
    if(tmr==0)	I2C_Err2 = 1;
	
    I2C_GenerateSTART(I2C2, ENABLE);
    //����I2C��START�źţ��ӿ��Զ��Ӵ��豸������豸
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)));
    if(tmr==0)	I2C_Err2 = 1;
	
    I2C_Send7bitAddress(I2C2,(I2C_Addr<<1)|0,I2C_Direction_Transmitter);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2,I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)));
    if(tmr==0)I2C_Err2 = 1;
	
    I2C_SendData(I2C2, Reg_addr);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2,I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
    if(tmr==0)I2C_Err2 = 1;
		
    I2C_GenerateSTART(I2C2, ENABLE);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)));
    if(tmr==0)	I2C_Err2 = 1;

    I2C_Send7bitAddress(I2C2,(I2C_Addr<<1)|1, I2C_Direction_Receiver);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED)));
    if(tmr==0)	I2C_Err2 = 1;

    I2C_AcknowledgeConfig(I2C2, DISABLE);
    I2C_GenerateSTOP(I2C2, ENABLE);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!(I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED))));  /* EV7 */
    if(tmr==0)	I2C_Err2 = 1;
    readout = I2C_ReceiveData(I2C2);

    I2C_AcknowledgeConfig(I2C2, ENABLE);

    return readout;
}

//дһ���ֽ�
void I2C2_WriteOneByte(uint8_t I2C_Addr,uint8_t Reg_addr,uint8_t value)
{
    uint32_t tmr;

    tmr = ulTimeOut_Time;
    while((--tmr)&&I2C_GetFlagStatus(I2C2, I2C_FLAG_BUSY));
    if(tmr==0)	I2C_Err2 = 1;

    I2C_GenerateSTART(I2C2, ENABLE);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT))); 
    if(tmr==0)	I2C_Err2 = 1;

    I2C_Send7bitAddress(I2C2, (I2C_Addr<<1)|0, I2C_Direction_Transmitter);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)));
    if(tmr==0) I2C_Err2 = 1;

    I2C_SendData(I2C2, Reg_addr);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
    if(tmr==0) I2C_Err2 = 1;

    I2C_SendData(I2C2, value);
    tmr = ulTimeOut_Time;
    while((--tmr)&&(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)));
    if(tmr==0) I2C_Err2 = 1;
    I2C_GenerateSTOP(I2C2, ENABLE);
    //I2C_AcknowledgeConfig(I2Cx, DISABLE);
}
#endif
