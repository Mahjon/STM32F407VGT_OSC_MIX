#include "dac.h"
#include <math.h>
#include "rng.h"
#define DAC_DHR12R1_ADDRESS 0x40007408

uint16_t DAC_Data[WAVE_DOT];
//DACͨ��1�����ʼ��
void Dac1_Init(void)
{  
  GPIO_InitTypeDef  GPIO_InitStructure;
	DAC_InitTypeDef DAC_InitType;
	DMA_InitTypeDef DMA_InitStructure;
	
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);//ʹ��GPIOAʱ��
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);//ʹ��DACʱ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1,ENABLE);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;//ģ������
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//����
  GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��

	DAC_InitType.DAC_Trigger=DAC_Trigger_T4_TRGO;	//��ʱ��4����
	DAC_InitType.DAC_WaveGeneration=DAC_WaveGeneration_None;//��ʹ�ò��η���
	//DAC_InitType.DAC_LFSRUnmask_TriangleAmplitude=DAC_LFSRUnmask_Bit0;//���Ρ���ֵ����
	DAC_InitType.DAC_OutputBuffer=DAC_OutputBuffer_Disable ;	//DAC1�������ر� BOFF1=1
  DAC_Init(DAC_Channel_1,&DAC_InitType);	 //��ʼ��DACͨ��1
  //DAC_SetChannel1Data(DAC_Align_12b_R, 0);  //12λ�Ҷ������ݸ�ʽ����DACֵ
	
	while(DMA_GetCmdStatus(DMA1_Stream5)!=DISABLE);
	DMA_DeInit(DMA1_Stream5);
	DMA_InitStructure.DMA_Channel = DMA_Channel_7; //dac1 ��DMA1 stream5 channel7
	DMA_InitStructure.DMA_PeripheralBaseAddr = DAC_DHR12R1_ADDRESS;//DAC_BASE(0x40007400)+DHR12R1_OFFSET(0x08)+DAC_Align_12b_R(0x00)
	DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)&DAC_Data;
	DMA_InitStructure.DMA_BufferSize = WAVE_DOT;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
	DMA_Init(DMA1_Stream5,&DMA_InitStructure);
	
	DMA_Cmd(DMA1_Stream5,ENABLE);
	DAC_Cmd(DAC_Channel_1, ENABLE);  //ʹ��DACͨ��1
	DAC_DMACmd(DAC_Channel_1,ENABLE);
}

//����ͨ��1�����ѹ
//vol:0~3300,����0~3.3V
void Dac1_Set_Vol(u16 vol)
{
	double temp=vol;
	temp/=1000;
	temp=temp*4096/3.3;
	DAC_SetChannel1Data(DAC_Align_12b_R,temp);//12λ�Ҷ������ݸ�ʽ����DACֵ
}

void Wave_Generator(WAVE_MODE mode,uint16_t voltage_max,uint16_t *wave_data)
{
	 uint16_t i = 0;
	 float tmp1;
	 short tmp2;
	 switch(mode)
	 {
		 case WAVE_SIN:
			 tmp1 = 2*3.1415926/WAVE_DOT;
			 for(i = 0;i<WAVE_DOT;i++)
				{
					wave_data[i] = 0.5*voltage_max*(sin(tmp1*i)+1);
				}
				break;
		 case WAVE_TRIANGLE:
			 if(WAVE_DOT%2)
			 {
				 tmp2 = WAVE_DOT/2 +1;
			 }
			 else 
				 tmp2 = WAVE_DOT/2;
			 for(i = 0; i<tmp2;i++)
			 {
				 wave_data[i] = i*voltage_max/tmp2;
			 }
			 for(i = tmp2;i<WAVE_DOT;i++)
			 {
				 wave_data[i] = voltage_max-voltage_max*(i-tmp2)/tmp2;
			 }
			 break;
			case WAVE_SAWTOOTH:
				for(i = 0;i<WAVE_DOT;i++)
				{
					wave_data[i] = voltage_max*i/WAVE_DOT;
				}
				break;
			case WAVE_SQUARE:
				for(i = 0;i<WAVE_DOT;i++)
				{
					if(i<64)wave_data[i] = voltage_max;
					else wave_data[i] = 0;
				}				
				break;
			case WAVE_CIRCLE:
				for(i=0;i<WAVE_DOT;i++)
				{
					wave_data[i] =2*voltage_max*sqrt(pow(WAVE_DOT/2,2)-pow(abs(i-64),2))/WAVE_DOT;
				}
				break;
			case WAVE_NOISE:
				for(i=0;i<WAVE_DOT;i++)
				{
					wave_data[i] =voltage_max*RNG_Get_RandomRange(0,128)/WAVE_DOT;
				}
				break;
			default:
				break;
	 }
}

