#ifndef _IDWG_H
#define _IDWG_H
#include "sys.h"

void IWDG_Init(uint8_t prer,uint16_t rlr);

#endif

