#ifndef _SPI_H
#define _SPI_H
#include "sys.h"

/***SPI1 GPIO***/
//PB5��MOSI
//PB4��MISO
//PB3: SCK
//PB0��CS
/***SPI2 GPIO***/
//PB15��MOSI
//PB14��MISO
//PB13: SCK
//PB12: CS
/***SPI3 GPIO***/
//PE11��MOSI
//PE9��	MISO
//PE8: 	SCK
//PE12: CS
/***SPI4 GPIO***/
//PD3��	MOSI
//PD4��	MISO
//PD5: 	SCK
//PD6: 	CS
/***SPI1***/
#define SPI1_SOFT 0						//0:ʹ��Ӳ��spi1 1:ʹ������ģ��spi1
#if SPI1_SOFT
#define SPI1_SCK PBout(3)
#define SPI1_MISO PBin(4)
#define SPI1_MOSI PBout(5)
#define SPI1_CS PBout(0)
#define SPI1_MODE 3
#else
void SPI1_SetSpeed(uint8_t SPI_BaudRatePrescaler);
void SPI2_SetSpeed(uint8_t SPI_BaudRatePrescaler);
#endif


/***SPI3***/
#define SPI3_SCK PEout(8)
#define SPI3_MISO PEin(9)
#define SPI3_MOSI PEout(11)
#define SPI3_CS PEout(12)
#define SPI3_MODE 0
/***SPI4***/
#define SPI4_SCK PDout(5)
#define SPI4_MISO PDin(4)
#define SPI4_MOSI PDout(3)
#define SPI4_CS PDout(6)
#define SPI4_MODE 0

void SPI1_Init(void);
void SPI2_Init(void);
void SPI3_Init(void);
void SPI4_Init(void);

uint8_t SPI1_ReadWriteByte(uint8_t data);
uint8_t SPI2_ReadWriteByte(uint8_t data);
uint8_t SPI3_ReadWriteByte(uint8_t data);
uint8_t SPI4_ReadWriteByte(uint8_t data);
void LCD_DMA1_Transfer(uint32_t data);
#endif
