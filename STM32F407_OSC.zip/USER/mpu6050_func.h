#ifndef _MPU6050_FUNC_H
#define _MPU6050_FUNC_H
#include "sys.h"

void mpu6050_refsresh(void);

#endif
