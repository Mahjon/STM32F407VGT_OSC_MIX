#ifndef _FFT_H
#define _FFT_H
#include "osc.h"
void fft_fuction(uint16_t *ad_data);
#endif
