#ifndef _KEY_H
#define _KEY_H
#include "sys.h"
#define KEY PDin(8)																			//��ť���� PD8
#define KNOB_A PDin(10)																	//��ťA PD10
#define KNOB_B PDin(9)																	//��ťB PD9
#define ENABLE_EXTI_LINE(n) {EXTI->IMR |= (n);}					//ʹ���ⲿ�ж���n
#define DISABLE_EXTI_LINE(n)	{EXTI->IMR &= ~(n);}			//ʧ���ⲿ�ж���n

enum KEY_STATE
{
	KEY_SHORT=0x11,
	KEY_LONG,
	KEY_IDLE,
	KEY_MAX
};

enum KNOB_STATE
{
	KNOB_CW=0x21,
	KNOB_CCW,
	KNOB_IDLE,
	KNOB_MAX
};

typedef struct
{
	uint8_t key_state;
	uint8_t knob_state;
}KEY_PAR;
extern KEY_PAR key1;
void Knob_Init(void);
void Key_Scan(u8 mode,KEY_PAR key);
#endif
