#ifndef _OLED_H
#define _OLED_H

#include <sys.h>
/*�궨��*/

#define OLED_ADDR 0x3c        //OLED ��ַ
#define I2C_CMD 0x00
#define I2C_DATA 0x40
#define OLED_WIDTH 128
#define OLED_HEIGHT 128
/*
I2C1
//PB9 OLED_EN;
//PB8 OLED_RES;
//PB6 OLED_SCL;
//PB7 OLED_SDA;
*/

#define OLED_RES_LOW() GPIO_ResetBits(GPIOB,GPIO_Pin_8)//OLED_RES
#define OLED_RES_HIGH() GPIO_SetBits(GPIOB,GPIO_Pin_8)
#define OLED_EN_LOW() GPIO_ResetBits(GPIOB,GPIO_Pin_9)//OLED_EN
#define OLED_EN_HIGH() GPIO_SetBits(GPIOB,GPIO_Pin_9)

/*#define OLED_SDA_OUT() {GPIO_InitTypeDef GPIO_OLED_SDA;\
												GPIO_OLED_SDA.GPIO_Pin=GPIO_Pin_14;\
												GPIO_OLED_SDA.GPIO_Mode=GPIO_Mode_OUT;\
												GPIO_OLED_SDA.GPIO_OType=GPIO_OType_PP;\
												GPIO_OLED_SDA.GPIO_PuPd=GPIO_PuPd_UP;\
												GPIO_OLED_SDA.GPIO_Speed=GPIO_Speed_50MHz;\
												GPIO_Init(GPIOE,&GPIO_OLED_SDA);}

#define OLED_SDA_IN() {GPIO_InitTypeDef GPIO_OLED_SDA;\
												GPIO_OLED_SDA.GPIO_Pin=GPIO_Pin_14;\
												GPIO_OLED_SDA.GPIO_Mode=GPIO_Mode_IN;\
												GPIO_OLED_SDA.GPIO_PuPd=GPIO_PuPd_NOPULL;\
												GPIO_OLED_SDA.GPIO_Speed=GPIO_Speed_50MHz;\
												GPIO_Init(GPIOE,&GPIO_OLED_SDA);}*/


/*ö�ٳ���*/
typedef enum
{
	font_6x8 = 6,
	font_8x16 = 8,
	font_max
}FONT_SIZE;

struct OLED_INFO
{
	uint8_t OLED_GDDRAM[OLED_HEIGHT/8][OLED_WIDTH];						//��ǰ֡
	uint8_t OLED_GDDRAM_LAST[OLED_HEIGHT/8][OLED_WIDTH];			//��һ֡
	uint8_t width;																						//��ʾ����
	uint8_t heigh;																						//��ʾ�߶�
};
extern struct OLED_INFO oled_par;
/*��������*/
void OLED_Init(void);
void OLED_Char(uint8_t x,uint8_t y,uint8_t chr,FONT_SIZE size,uint8_t reverse);	
void OLED_NUM(uint8_t x, uint8_t y,uint16_t num,uint8_t len,FONT_SIZE size,uint8_t reverse);
void OLED_String(uint8_t x,uint8_t y,char *str,FONT_SIZE size,uint8_t reverse);
void OLED_DrawPoint(uint8_t x,uint8_t y,uint8_t p);
void OLED_DrawLine(uint8_t x1,uint8_t y1,uint8_t x2,uint8_t y2);
void OLED_DrawSquare(uint8_t x1,uint8_t y1,uint8_t x2,uint8_t y2);		
void OLED_Fillsquare(uint8_t x1,uint8_t y1,uint8_t x2,uint8_t y2,uint8_t p);
void OLED_DrawCircle(uint8_t x,uint8_t y,uint8_t r);
void OLED_DrawCircleFill(uint8_t x,uint8_t y,uint8_t r);
void OLED_Frame(struct OLED_INFO *oled); //GDDRAM ˢ��
//void Draw_grid(void);
//void OLED_Frame_local(uint8_t sy,uint8_t ey);
//void OLED_Frame_local_clean(uint8_t sy,uint8_t ey);
void OLED_DrawPic(uint8_t x,uint8_t y ,uint16_t width,uint16_t height,uint8_t **img,uint8_t reverse);
#endif
