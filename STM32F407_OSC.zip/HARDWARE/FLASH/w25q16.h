#ifndef _W25Q16_H
#define _W25Q16_H
#include "sys.h"
#define W25Q16_CS PAout(15)
#define WRITE_ENABLE 0x06
#define WRITE_DISABLE 0x04
#define READ_STATUS_REGISTER_1 0x05
#define WRITE_STATUS_REGISTER_1 0x01
#define CHIP_ERASE 0xc7 //0xc7 or 0x60
#define SECTOR_ERASE 0x20
#define POWER_DOWN 0xb9
#define RELEASE_POWEER_DOWN 0xab
#define READ_DATA 0x03
#define FAST_READ_DATA 0x0b
#define PAGE_PROGRAM 0x02
#define READ_DEVICE_ID 0x90
#define READ_JEDEC_ID 0x9f

extern uint16_t W25Q16_ID;
uint16_t W25Q16_ReadID(void);																		//��ID
void W25Q16_Init(void);																					//flash��ʼ��
void W25Q16_Chip_Erase(void);																		//flash��Ƭ����
void W25Q16_Wake_Up(void);																			//�˳��͵�ģʽ
void W25Q16_Write(u8* pBuffer,u32 WriteAddr,u16 NumByteToWrite);//д��ָ��λ�ô�С������
void W25Q16_Read(uint8_t *pBuffer,uint32_t addr,uint16_t size); //��ȡָ��λ�ô�С������
#endif
