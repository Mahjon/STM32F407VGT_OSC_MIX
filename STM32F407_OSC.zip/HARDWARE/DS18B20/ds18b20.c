#include "ds18b20.h"
#include "delay.h"

//DS18B20��λ
void DS18B20_Reset(void)
{
	DS18B20_DQ_MODE_OUT;
	DS18B20_DQ_OUT = 0;
	delay_us(750);
	DS18B20_DQ_OUT = 1;
	delay_us(15);
}

//DS18B20���
uint8_t DS18B20_Check(void)
{
	uint8_t time_out;
	DS18B20_DQ_MODE_IN;
	while(DS18B20_DQ_IN && time_out<200) //�ȴ�DQ����
	{
		time_out++;
		delay_us(1);
	}
	if(time_out>=200) return 1;
	else time_out = 0;
	
	while(!DS18B20_DQ_IN && time_out<240) //�ȴ�DQ����
	{
		time_out++;
		delay_us(1);
	}	
	if(time_out>=240) return 1;
	return 0;
}
//��DS18B20��ȡһ��λ
//����ֵ��1/0
uint8_t DS18B20_Read_Bit(void)
{
	uint8_t data;
	DS18B20_DQ_MODE_OUT;
	DS18B20_DQ_OUT = 0;
	delay_us(2);
	DS18B20_DQ_OUT = 1;
	DS18B20_DQ_MODE_IN;
	delay_us(12);
	if(DS18B20_DQ_IN) data = 1;
	else data = 0;
	delay_us(50);
	return data;
}

//��DS18B20��ȡһ���ֽ�
//����ֵ������������
uint8_t DS18B20_Read_Byte(void)    
{        
	uint8_t i,j,data;
	data=0;
	for (i=1;i<=8;i++) 
	{
		j=DS18B20_Read_Bit();
		data=(j<<7)|(data>>1);		//�ȶ���λ
  }						    
  return data;
}

//дһ���ֽڵ�DS18B20
//dat��Ҫд����ֽ�
void DS18B20_Write_Byte(uint8_t data)     
 {             
   uint8_t i,tmp_bit;
	 DS18B20_DQ_MODE_OUT;
   for (i=1;i<=8;i++) 
		{
			tmp_bit=data&0x01;          //��д��λ
			data=data>>1;
			if (tmp_bit) 
			{
				DS18B20_DQ_OUT=0;			// Write 1
				delay_us(2);                            
				DS18B20_DQ_OUT=1;
				delay_us(60);             
			}
			else 
			{
				DS18B20_DQ_OUT=0;			// Write 1
				delay_us(60);             
				DS18B20_DQ_OUT=1;
				delay_us(2);                          
			}
	 }
}

//��ʼ�¶�ת��
void DS18B20_Start(void)			// ds1820 start convert
{   						               
    DS18B20_Reset();	   
	  DS18B20_Check();	 
    DS18B20_Write_Byte(0xcc);	// skip rom
    DS18B20_Write_Byte(0x44);	// convert
} 

//��ds18b20�õ��¶�ֵ
//���ȣ�0.1C
//����ֵ���¶�ֵ ��-550~1250�� 
short DS18B20_Get_Temp(void)
{
    uint8_t flag_temp;
    uint8_t TL,TH;
	  short temp;
    DS18B20_Start ();         // ds1820 start convert
    DS18B20_Reset();
    DS18B20_Check();	 
    DS18B20_Write_Byte(0xcc);	// skip rom
    DS18B20_Write_Byte(0xbe);	// convert	    
    TL=DS18B20_Read_Byte(); 	// LSB   
    TH=DS18B20_Read_Byte(); 	// MSB   
    if(TH>7)
    {
			TH=~TH;
			TL=~TL; 
			flag_temp=0;//�¶�Ϊ��  
    }else flag_temp=1;//�¶�Ϊ��	  	  
    temp=TH; //��ø߰�λ
    temp<<=8;    
    temp+=TL;//��õװ�λ
    temp=(double)temp*0.625;//ת��     
	if(flag_temp)return temp; //�����¶�ֵ
	else return -temp;    
}

uint8_t DS18B20_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;								//DS18B20 DQ���������� PE15
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOE,&GPIO_InitStructure);
	
	DS18B20_Reset();
	return DS18B20_Check();
}
