#ifndef _DS18B20_H
#define _DS18B20_H
#include "sys.h"

#define DS18B20_DQ_MODE_OUT do{GPIOE->MODER&=~(3<<(15*2));GPIOE->MODER|=1<<15*2;}while(0)	//PE15���ģʽ
#define DS18B20_DQ_MODE_IN	do{GPIOE->MODER&=~(3<<(15*2));GPIOE->MODER|=0<<15*2;}while(0)	//PE15����ģʽ

#define DS18B20_DQ_OUT PEout(15)
#define DS18B20_DQ_IN PEin(15)

uint8_t DS18B20_Init(void);
short DS18B20_Get_Temp(void);
#endif

