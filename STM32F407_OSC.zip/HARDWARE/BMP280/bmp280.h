#ifndef _BMP280_H
#define _BMP280_H
#include "sys.h"
//iic�ٶ�������ó�100kHz
#define BMP280_ADDR 0x76 //SD0�Ž�GND��ַ:0x76 SD0�Ž�VCC��ַ:0x0x77
#define BMP280_REG_ID 0xd0
#define BMP280_REG_RESET 0xe0
#define BMP280_REG_CTRL_MEAS 0xf4
#define BMP280_REG_CONFIG 0xf5
#define BMP280_REG_TEMP 0xfa
#define BMP280_REG_PRESS 0xf7

typedef struct
{
	uint16_t dig_T1;
	int16_t dig_T2;
	int16_t dig_T3;
	uint16_t dig_P1;
	int16_t dig_P2;
	int16_t dig_P3;
	int16_t dig_P4;
	int16_t dig_P5;
	int16_t dig_P6;
	int16_t dig_P7;
	int16_t dig_P8;
	int16_t dig_P9;
	int32_t t_fine;
}BMP280_COMPENSATION;

typedef struct 
{
	uint8_t bmp280_id;													//bmp280 id
	float bmp280_pressure;											//bmp280 ����ѹ
	float bmp280_temp;													//bmp280 �¶�
	float bmp280_elevation;											//����
	BMP280_COMPENSATION bmp280_offset;
}BMP280_DEV;


extern BMP280_DEV bmp280_par;

void BMP280_Init(void);
double BMP280_Get_Temp(void);
double BMP280_Get_Press(void);
#endif

