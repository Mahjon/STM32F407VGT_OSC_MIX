#include "bmp280.h"
#include "hardiic.h"
#include "delay.h"

BMP280_DEV bmp280_par;


uint16_t BMP280_Read_Two_Bytes(uint8_t reg_addr)
{
	uint8_t lsb,msb;
	uint16_t tmp = 0;
	lsb = I2C2_ReadOneByte(BMP280_ADDR,reg_addr);
	msb = I2C2_ReadOneByte(BMP280_ADDR,reg_addr+1);
	tmp = msb<<8;
	tmp |= lsb;
	return tmp;
}
int32_t BMP280_Read_Three_Bytes(uint8_t reg_addr)
{
	uint8_t xlsb,lsb,msb;
	int32_t tmp;
	msb = I2C2_ReadOneByte(BMP280_ADDR,reg_addr);
	lsb = I2C2_ReadOneByte(BMP280_ADDR,reg_addr+1);
	xlsb = I2C2_ReadOneByte(BMP280_ADDR,reg_addr+2);
	tmp = ((msb<<12) | (lsb<<4) | (xlsb>>4));
	return tmp;
}

void BMP280_Init(void)
{
	I2C2_Config();
	//��ʼ������
	//step.1 ��λ
	I2C2_WriteOneByte(BMP280_ADDR,BMP280_REG_RESET,0xb6);													//����λ�Ĵ���0xe0д��0xb6���мĴ�����������
	//step.2 ��ȡid
	bmp280_par.bmp280_id = I2C2_ReadOneByte(BMP280_ADDR,BMP280_REG_ID);						//��ȡID
	//step.3 ���ò������ƼĴ���
	I2C2_WriteOneByte(BMP280_ADDR,BMP280_REG_CTRL_MEAS,0xff);											//�¶Ȳ�������bit[7:5]=111��110��101(20bit) 100(19bit) ... 001(16bit)
																																								//��ѹ��������bit[4:2]=ͬ��
																																								//ģʽbit[1:0]: 00(sleep mode) 01/10(force mode) 11(normal mode)
	//step.4 �������üĴ�
	I2C2_WriteOneByte(BMP280_ADDR,BMP280_REG_CONFIG,0x04);												//ת��ʱ��bit[7:5]=000(0.5ms)	001(62.5ms) 010(125ms) 011(250ms) 100(500ms) 101(1000ms) 110(2000ms) 111(4000ms)
																																								//IIR�˲�bit[4:2]	000(filter off) 001(0.223*ODR) 010(0.092) 011(0.042) 100(0.021) ODR:�����������
																																								//ʹ��3��spi bit[1:0]
	//step.5 ��ȡ����ֵ
	bmp280_par.bmp280_offset.dig_T1 = BMP280_Read_Two_Bytes(0x88);
	bmp280_par.bmp280_offset.dig_T2 = BMP280_Read_Two_Bytes(0x8a);
	bmp280_par.bmp280_offset.dig_T3 = BMP280_Read_Two_Bytes(0x8c);
	bmp280_par.bmp280_offset.dig_P1 = BMP280_Read_Two_Bytes(0x8e);
	bmp280_par.bmp280_offset.dig_P2 = BMP280_Read_Two_Bytes(0x90);
	bmp280_par.bmp280_offset.dig_P3 = BMP280_Read_Two_Bytes(0x92);
	bmp280_par.bmp280_offset.dig_P4 = BMP280_Read_Two_Bytes(0x94);
	bmp280_par.bmp280_offset.dig_P5 = BMP280_Read_Two_Bytes(0x96);
	bmp280_par.bmp280_offset.dig_P6 = BMP280_Read_Two_Bytes(0x98);
	bmp280_par.bmp280_offset.dig_P7 = BMP280_Read_Two_Bytes(0x9a);
	bmp280_par.bmp280_offset.dig_P8 = BMP280_Read_Two_Bytes(0x9c);
	bmp280_par.bmp280_offset.dig_P9 = BMP280_Read_Two_Bytes(0x9e);	
	delay_ms(200);
	
}	

//��ȡ�¶�ֵ
double BMP280_Get_Temp(void)
{
	double tmp1,tmp2,tmp3;
	int32_t tmp;
	tmp = BMP280_Read_Three_Bytes(BMP280_REG_TEMP);															//��ȡ�¶�adֵ
	tmp1 = (((double)tmp)/16384.0 - ((double)bmp280_par.bmp280_offset.dig_T1)/1024.0)*((double)bmp280_par.bmp280_offset.dig_T2);
	tmp2 = ((((double)tmp)/131072.0 - ((double)bmp280_par.bmp280_offset.dig_T1)/8192.0)\
					*(((double)tmp)/131072.0 - ((double)bmp280_par.bmp280_offset.dig_T1)/8192.0))\
					*((double)bmp280_par.bmp280_offset.dig_T3);
	bmp280_par.bmp280_offset.t_fine = (int32_t)(tmp1+tmp2);
	tmp3 = (tmp1+tmp2)/5120.0;
	return tmp3;
}

//��ȡ��ѹֵ

double BMP280_Get_Press(void)
{
	double tmp1,tmp2,tmp3;
	int32_t tmp;
	tmp = BMP280_Read_Three_Bytes(BMP280_REG_PRESS);															//��ȡ��ѹadֵ
	if(tmp == 0) return 0;
	
	tmp1 = ((double)bmp280_par.bmp280_offset.t_fine)/2.0-64000.0;
	tmp2 = tmp1*tmp1*((double)bmp280_par.bmp280_offset.dig_P6)/32768.0;
	tmp2 = tmp2+tmp1*((double)bmp280_par.bmp280_offset.dig_P5)*2.0;
	tmp2 = (tmp2/4.0)+(((double)bmp280_par.bmp280_offset.dig_P4)*65536.0);
	tmp1 = (((double)bmp280_par.bmp280_offset.dig_P3)*tmp1*tmp1/524288.0\
					+((double)bmp280_par.bmp280_offset.dig_P2)*tmp1)/524288.0;
	tmp1 = (1.0+tmp1/32768.0)*((double)bmp280_par.bmp280_offset.dig_P1);
	
	tmp3 = 1048576.0 - (double)tmp;
	tmp3 = (tmp3 - (tmp2/4096.0))*6250.0/tmp1;
	tmp1 = ((double)bmp280_par.bmp280_offset.dig_P9)*tmp3*tmp3/2147483648.0;
	tmp2 = tmp3*((double)bmp280_par.bmp280_offset.dig_P8)/32768.0;
	tmp3 = tmp3 +(tmp1+tmp2+((double)bmp280_par.bmp280_offset.dig_P7))/16.0;
	return tmp3;


//    double tmp1, tmp2, tmp3;
//		int32_t tmp;
//		tmp = BMP280_Read_Three_Bytes(BMP280_REG_PRESS);															//��ȡ��ѹadֵ
//    tmp1 = ((double) bmp280_par.bmp280_offset.t_fine / 2.0) - 64000.0;
//    tmp2 = tmp1 * tmp1 * ((double) bmp280_par.bmp280_offset.dig_P6) / 32768.0;
//    tmp2 = tmp2 + tmp1 * ((double) bmp280_par.bmp280_offset.dig_P5) * 2.0;
//    tmp2 = (tmp2 / 4.0) + (((double) bmp280_par.bmp280_offset.dig_P4) * 65536.0);
//    tmp1 = (((double) bmp280_par.bmp280_offset.dig_P3) * tmp1 * tmp1 / 524288.0
//            + ((double) bmp280_par.bmp280_offset.dig_P2) * tmp1) / 524288.0;
//    tmp1 = (1.0 + tmp1 / 32768.0) * ((double) bmp280_par.bmp280_offset.dig_P1);
// 
//    if (tmp1 == 0.0) {
//        return 0; // avoid exception caused by division by zero
//    }
// 
//    tmp3 = 1048576.0 - (double) tmp;
//    tmp3 = (tmp3 - (tmp2 / 4096.0)) * 6250.0 / tmp1;
//    tmp1 = ((double) bmp280_par.bmp280_offset.dig_P9) * tmp3 * tmp3 / 2147483648.0;
//    tmp2 = tmp3 * ((double) bmp280_par.bmp280_offset.dig_P8) / 32768.0;
//    tmp3 = tmp3 + (tmp1 + tmp2 + ((double) bmp280_par.bmp280_offset.dig_P7)) / 16.0;
// 
//    return tmp3;
}
