#include "dht11.h"
#include "delay.h"

//复位DHT11
void DHT11_Reset(void)
{
	DHT11_DQ_MODE_OUT;
	DHT11_DQ_OUT = 0;
	delay_ms(30);			//主机发起复位需要18ms
	DHT11_DQ_OUT = 1;
	delay_us(40);
}

//等待DHT11的回应
//返回1:未检测到DHT11的存在
//返回0:存在
uint8_t DHT11_Check(void)
{
	uint8_t time_out;
	DHT11_DQ_MODE_IN;
	while (DHT11_DQ_IN && time_out<100)
	{
		time_out++;
		delay_us(1);
	}
	if(time_out>=100)	
		return 1;
	time_out = 0;
	while (!DHT11_DQ_IN && time_out<100)
	{
		time_out++;
		delay_us(1);
	}
	if (time_out >= 100)	
		return 1;
	return 0;	
}

//从DHT11读取一个位
//返回值：1或0
uint8_t DHT11_Read_Bit(void)
{
	uint8_t time_out = 0;
	while (DHT11_DQ_IN && time_out<100)
	{
		time_out++;
		delay_us(1);
	}
	time_out = 0;
	while (!DHT11_DQ_IN && time_out<100)
	{
		time_out++;
		delay_us(1);
	}
	delay_us(40);
	if(DHT11_DQ_IN) return 1;
	else return 0;
}

//从DHT11读取一个字节
//返回值：读到的数据
uint8_t DHT11_Read_Byte(void)
{
	uint8_t i,data=0;
	for(i=0;i<8;i++)
	{
		data<<=1;
		data |= DHT11_Read_Bit();
	}
	return data;
}

//从DHT11读取一次数据
//temp:温度值(范围:0~50°)
//humi:湿度值(范围:20%~90%)
//返回值：0,正常;1,读取失败
uint8_t DHT11_Read_Date(uint16_t *temp,uint8_t *humi)
{
	uint8_t buffer[5];
	uint8_t i;
	DHT11_Reset();
	if(DHT11_Check() == 0)
	{
		for ( i = 0; i < 5; i++)
		{
			buffer[i] = DHT11_Read_Byte();
		}
		if(buffer[0] + buffer[1] + buffer[2] + buffer[3] == buffer[4] ) //humi:buffer[0:整数部分-1:小数部分] temp:buffer[2-3]
		{
			*temp = buffer[2]*10+buffer[3];
			*humi = buffer[0];
		}
		else return 1;
	}
	else return 1;
	return 0;
}

uint8_t DHT11_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOE,&GPIO_InitStructure);

	DHT11_Reset();
	return DHT11_Check();
}

