#ifndef _DHT11_H
#define _DHT11_H
#include "sys.h"
//DHT11 湿度数据没有小数部分
#define DHT11_DQ_MODE_OUT   do{GPIOE->MODER&=~(3<<(15*2));GPIOE->MODER|=1<<15*2;}while(0)	//PE15输出模式
#define DHT11_DQ_MODE_IN    do{GPIOE->MODER&=~(3<<(15*2));GPIOE->MODER|=0<<15*2;}while(0)	//PE15输入模式

#define DHT11_DQ_OUT PEout(15)
#define DHT11_DQ_IN PEin(15)
uint8_t DHT11_Init(void);
uint8_t DHT11_Read_Date(uint16_t *temp,uint8_t *humi);
#endif
