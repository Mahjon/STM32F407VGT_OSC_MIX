#include "led.h"
#include "stm32f4xx.h"

void Led_Init(void)
{
	GPIO_InitTypeDef LED1;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
	LED1.GPIO_Mode=GPIO_Mode_OUT; //output
	LED1.GPIO_OType=GPIO_OType_PP;
	LED1.GPIO_Pin=GPIO_Pin_1;  //PA1 LED ����
	LED1.GPIO_PuPd=GPIO_PuPd_UP;//
	LED1.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_Init(GPIOA,&LED1);
	GPIO_SetBits(GPIOA,GPIO_Pin_1);   //default LED off
}
