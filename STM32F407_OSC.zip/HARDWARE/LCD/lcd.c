#include "lcd.h"
#include "spi.h"
#include "delay.h"
#include <stdlib.h>
#include <string.h>
#include "icon.h"

LCD_INFO lcd_dev;

/**LCD ����GPIO**/
//RESET:PE13
//DC:PE14
//CS:PB12
void LCD_GPIO_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14;
	GPIO_Init(GPIOE,&GPIO_InitStructure);
}


/**LCDд����**/
void LCD_Write_REG(uint8_t cmd)
{
	LCD_CS = 0;
	LCD_DC = 0;
	SPI2_ReadWriteByte(cmd);
	LCD_CS = 1;
}

/**LCDд����1**/
void LCD_Write_Data(uint8_t data)
{	
	uint8_t color;
	color = data;
	LCD_CS = 0;
	LCD_DC = 1;
	SPI2_ReadWriteByte(data);
	LCD_CS = 1;
}

/**LCDд����2**/
void LCD_Write_Data_16Bit(uint16_t data)
{

	LCD_CS = 0;
	LCD_DC = 1;
	SPI2_ReadWriteByte(data>>8);
	SPI2_ReadWriteByte(data);
	
	LCD_CS = 1;
}
/**�����𻭲���С**/
void LCD_Set_Canvas(uint16_t x_start,uint16_t y_start,uint16_t x_end,uint16_t y_end)
{
	LCD_Write_REG(lcd_dev.setxcmd);
	LCD_Write_Data(x_start>>8);
	LCD_Write_Data(0x00ff&x_start);
	LCD_Write_Data(x_end>>8);
	LCD_Write_Data(0x00ff&x_end);	
	
	LCD_Write_REG(lcd_dev.setycmd);
	LCD_Write_Data(y_start>>8);
	LCD_Write_Data(0x00ff&y_start);
	LCD_Write_Data(y_end>>8);
	LCD_Write_Data(0x00ff&y_end);	
	
	LCD_Write_REG(lcd_dev.wramcmd);
}

/**������ʵ�**/
void LCD_Set_Point(uint16_t x,uint16_t y)
{
	LCD_Set_Canvas(x,y,x,y);
}


/**����**/
void LCD_Draw_Point(uint16_t x,uint16_t y,uint16_t color)
{
	LCD_Set_Point(x,y);
	LCD_Write_Data_16Bit(color);
}

/**��Բ1**/
void LCD_Draw_Pre_Circle(int xc, int yc, int x, int y, uint16_t c)
{
	LCD_Draw_Point(xc + x, yc + y, c);
	LCD_Draw_Point(xc - x, yc + y, c);
	LCD_Draw_Point(xc + x, yc - y, c);
	LCD_Draw_Point(xc - x, yc - y, c);
	LCD_Draw_Point(xc + y, yc + x, c);
	LCD_Draw_Point(xc - y, yc + x, c);
	LCD_Draw_Point(xc + y, yc - x, c);
	LCD_Draw_Point(xc - y, yc - x, c);
}

/**��Բ**/
//xc:Բ��x����
//yc:Բ��y����

void LCD_Draw_Circle(uint16_t xc, uint16_t yc,uint16_t r,uint16_t c, uint8_t fill)
{
	int x = 0, y = r, yi, d;

	d = 3 - 2 * r;


	if (fill) 
	{
		// �����䣨��ʵ��Բ��
		while (x <= y) {
			for (yi = x; yi <= y; yi++)
				LCD_Draw_Pre_Circle(xc, yc, x, yi, c);

			if (d < 0) {
				d = d + 4 * x + 6;
			} else {
				d = d + 4 * (x - y) + 10;
				y--;
			}
			x++;
		}
	} else 
	{
		// �������䣨������Բ��
		while (x <= y) {
			LCD_Draw_Pre_Circle(xc, yc, x, y, c);
			if (d < 0) {
				d = d + 4 * x + 6;
			} else {
				d = d + 4 * (x - y) + 10;
				y--;
			}
			x++;
		}
	}	
}

/**��ͼ**/
/*****************************************************************************
 * @name       :void Gui_Drawbmp16(u16 x,u16 y,const unsigned char *p)
 * @date       :2021-09-13 
 * @function   :Display a 16-bit BMP image
 * @parameters :x:the beginning x coordinate of the BMP image
                y:the beginning y coordinate of the BMP image
								width: width pixel
								height: height pixel
								p:the start address of image array
 * @retvalue   :None
******************************************************************************/ 
void LCD_Draw_pic(uint16_t x,uint16_t y,uint16_t width,uint16_t height,const uint8_t *p)
{
	uint16_t i,x_tmp,y_tmp;
	if(x+width>lcd_dev.width || y+height>lcd_dev.height) return;
	LCD_Set_Canvas(x,y,x+width-1,y+height-1);
	for(i=0;i<width*height;i++)	LCD_Write_Data_16Bit(*(p+2*i) | (*(p+2*i+1)<<8));
	LCD_Set_Canvas(0,0,lcd_dev.width-1,lcd_dev.height-1);	//�ָ�������С
}
/**����**/
void LCD_Clean(uint16_t color)
{
	uint16_t i,j;
	LCD_Set_Canvas(0,0,lcd_dev.width-1,lcd_dev.height-1);
	for(i=0;i<lcd_dev.height;i++)
	{
		for(j=0;j<lcd_dev.width;j++) LCD_Write_Data_16Bit(color);
	}
}
/**��**/
//4��spiģʽ�²�֧��

/**LCD��ת**/
void LCD_Rotation(void)
{
	switch(lcd_dev.dir)
	{
		case 0:
			lcd_dev.width = LCD_W;
			lcd_dev.height = LCD_H;
			LCD_Write_REG(0x36);
			LCD_Write_Data(0x08);				//0 degree BGR==1,MY==0,MX==0,MV==0
			break;
		case 1:
			lcd_dev.width = LCD_H;
			lcd_dev.height = LCD_W;
			LCD_Write_REG(0x36);
			LCD_Write_Data(0x68);//90 degree BGR==1,MY==1,MX==0,MV==1
			break;
		case 2:
			lcd_dev.width = LCD_W;
			lcd_dev.height = LCD_H;
			LCD_Write_REG(0x36);
			LCD_Write_Data(0xc8);				//180 degree BGR==1,MY==0,MX==0,MV==0	
			break;
		case 3:
			lcd_dev.width = LCD_H;
			lcd_dev.height = LCD_W;
			LCD_Write_REG(0x36);
			LCD_Write_Data(0xa8);				//270 degree BGR==1,MY==1,MX==0,MV==1	
			break;
		default:
			break;
	}
}

void LCD_Info_Default(void)
{
	lcd_dev.width = LCD_W;
	lcd_dev.height = LCD_H;
	lcd_dev.id = 0x9341;
	lcd_dev.dir = LCD_DIRECTION_90;
	lcd_dev.setxcmd = 0x2a;				//������
	lcd_dev.setycmd = 0x2b;				//����ҳ
	lcd_dev.wramcmd = 0x2c;				//д��������
	lcd_dev.pen_color = BLACK;
}
void LCD_Init(void)
{
	SPI2_Init();
	LCD_GPIO_Init();

	LCD_RESET = 0;
	delay_ms(100);	
	LCD_RESET = 1;
	delay_ms(50);
	LCD_Write_REG(0x11);			//�˳�˯��
	LCD_Write_REG(0xcf);			//��Դ����b
	LCD_Write_Data(0x00);
	LCD_Write_Data(0xd9);
	LCD_Write_Data(0x30);
	
	LCD_Write_REG(0xed);			//�ϵ�˳��
	LCD_Write_Data(0x64);
	LCD_Write_Data(0x03);
	LCD_Write_Data(0x12);
	LCD_Write_Data(0x81);	
	
	LCD_Write_REG(0xe8);			//ʱ�������a
	LCD_Write_Data(0x85);
	LCD_Write_Data(0x10);
	LCD_Write_Data(0x7a);

	LCD_Write_REG(0xcb);			//��Դ����a
	LCD_Write_Data(0x39);
	LCD_Write_Data(0x2c);
	LCD_Write_Data(0x00);
	LCD_Write_Data(0x34);		
	LCD_Write_Data(0x02);	
	
	LCD_Write_REG(0xf7);			//�ñ�������
	LCD_Write_Data(0x20);	

	LCD_Write_REG(0xea);			//ʱ�������b
	LCD_Write_Data(0x00);	
	LCD_Write_Data(0x00);	
	
	LCD_Write_REG(0xc0);			//��Դ����1
	LCD_Write_Data(0x1b);	

	LCD_Write_REG(0xc1);			//��Դ����2
	LCD_Write_Data(0x12);

	LCD_Write_REG(0xc5);			//VCOM ����1
	LCD_Write_Data(0x08);
	LCD_Write_Data(0x26);
	
	LCD_Write_REG(0xc7);			//VCOM ����2
	LCD_Write_Data(0xb7);

	LCD_Write_REG(0x36);			//�Դ����
	LCD_Write_Data(0x08);
	
	LCD_Write_REG(0x3a);			//�������ݸ�ʽ
	LCD_Write_Data(0x55);			//RGB�ӿڣ�16bit MCU�ӿڣ�16bit
	
	LCD_Write_REG(0xb1);			//֡��
	LCD_Write_Data(0x00);			//f=fosc 
	LCD_Write_Data(0x1a);			//f=73hz

	LCD_Write_REG(0xb6);			//ɨ������
	LCD_Write_Data(0x0a);			//f=fosc 
	LCD_Write_Data(0xa2);			//f=73hz
	
	LCD_Write_REG(0xf2);			//gamar 3ʹ������
	LCD_Write_Data(0x00);			//��ֹ

	LCD_Write_REG(0x26);			//gamar����
	LCD_Write_Data(0x01);			//٤������1
	
	LCD_Write_REG(0xe0);			//��gamarУ��
	LCD_Write_Data(0x0f);
	LCD_Write_Data(0x1d);
	LCD_Write_Data(0x1a);
	LCD_Write_Data(0x0a);
	LCD_Write_Data(0x0d);
	LCD_Write_Data(0x07);
	LCD_Write_Data(0x49);
	LCD_Write_Data(0x66);
	LCD_Write_Data(0x3b);
	LCD_Write_Data(0x07);
	LCD_Write_Data(0x11);
	LCD_Write_Data(0x01);
	LCD_Write_Data(0x09);
	LCD_Write_Data(0x05);
	LCD_Write_Data(0x04);

	LCD_Write_REG(0xe1);			//��gamarУ��
	LCD_Write_Data(0x00);
	LCD_Write_Data(0x18);
	LCD_Write_Data(0x1d);
	LCD_Write_Data(0x02);
	LCD_Write_Data(0x0f);
	LCD_Write_Data(0x04);
	LCD_Write_Data(0x36);
	LCD_Write_Data(0x13);
	LCD_Write_Data(0x4c);
	LCD_Write_Data(0x07);
	LCD_Write_Data(0x13);
	LCD_Write_Data(0x0f);
	LCD_Write_Data(0x2e);
	LCD_Write_Data(0x2f);
	LCD_Write_Data(0x05);
	
	LCD_Write_REG(0x2b);			//ҳ��ַ����
	LCD_Write_Data(0x00);			
	LCD_Write_Data(0x00);			//0
	LCD_Write_Data(0x01);			//320
	LCD_Write_Data(0x3f);			//
	
	LCD_Write_REG(0x2a);			//�е�ַ����
	LCD_Write_Data(0x00);			//��ʼ�и�8λ 
	LCD_Write_Data(0x00);			//��ʼ�е�8λ	0
	LCD_Write_Data(0x00);			//�����и�8λ
	LCD_Write_Data(0xef);			//�����е�8λ 239
	
	LCD_Write_REG(0x11);			//�˳�˯��
	delay_ms(10);
	LCD_Write_REG(0x29);			//��ʾ�� 0x28 :��
//	LCD_Write_REG(0x20);			//��ɫ�� 0x21 :��
	delay_ms(10);
	LCD_Info_Default();	
	LCD_Rotation();						//������ʾ����
	LCD_Clean(WHITE);
	
}